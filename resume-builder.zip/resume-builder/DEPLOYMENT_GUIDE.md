# Deploying Resume Minter to Hostinger — Step by Step

This guide walks through taking the code in this repo from your machine to a
live, paying-customers-welcome website on Hostinger, using:

- **Hostinger VPS (KVM)** to run the Node.js backend and serve the React frontend
- **MongoDB Atlas** (free tier) as the database — Hostinger doesn't offer managed MongoDB, and Atlas's free M0 tier is the standard choice for a project this size
- **Razorpay** for subscription billing

## 0. Prerequisites

- A Hostinger account with a domain (either bought through Hostinger or pointed at it from elsewhere)
- A GitHub account (to push this code somewhere you can `git clone` from your server) — or you can `scp`/upload a zip instead
- A MongoDB Atlas account (free): https://www.mongodb.com/cloud/atlas/register
- A Razorpay account: https://razorpay.com/

## 1. Choose and buy a Hostinger VPS plan

Go to Hostinger → VPS Hosting. As of writing, the KVM plans are:

| Plan  | vCPU | RAM   | Storage    | Good for |
|-------|------|-------|------------|----------|
| KVM 1 | 1    | 4 GB  | 50 GB NVMe | Testing / very early traffic |
| KVM 2 | 2    | 8 GB  | 100 GB NVMe| **Recommended starting point** |
| KVM 4 | 4    | 16 GB | 200 GB NVMe| Growing traffic |

**KVM 2** is the sensible starting point: Puppeteer (used for PDF generation)
launches a full headless Chrome per export, which is memory-hungry — the 4GB
KVM 1 plan will work but leaves little headroom. Choose an OS image of
**Ubuntu 22.04 LTS** during setup.

Note: Hostinger's advertised prices are usually a discounted rate for a long
signup term (e.g. 24 months); check the renewal price before committing.

## 2. Point your domain at the VPS

In Hostinger's hPanel, under your VPS, note its public IP address. Then, in
your domain's DNS settings (in hPanel if the domain is with Hostinger, or
your registrar if not), add:

- An **A record**: `@` → `<your VPS IP>`
- An **A record**: `www` → `<your VPS IP>`

DNS propagation can take a few minutes to a few hours.

## 3. Initial server setup

SSH into your VPS (Hostinger gives you the root password / lets you upload an
SSH key in hPanel):

```bash
ssh root@your-vps-ip
```

Then:

```bash
apt update && apt upgrade -y

# Create a non-root user to run things day-to-day
adduser deploy
usermod -aG sudo deploy

# Basic firewall
ufw allow OpenSSH
ufw allow 80
ufw allow 443
ufw enable

# Switch to the new user for everything below
su - deploy
```

## 4. Install Node.js, PM2, Nginx, and Certbot

```bash
# Node.js 20.x via NodeSource
curl -fsSL https://deb.nodesource.com/setup_20.x | sudo -E bash -
sudo apt install -y nodejs

node -v   # confirm v20.x
npm -v

# PM2 keeps the Node process alive, restarts it on crash/reboot
sudo npm install -g pm2

# Nginx will serve the frontend and reverse-proxy API requests
sudo apt install -y nginx

# Certbot for free HTTPS certificates
sudo apt install -y certbot python3-certbot-nginx
```

Puppeteer (used for PDF export) needs a handful of system libraries to run
headless Chrome on a bare Ubuntu server:

```bash
sudo apt install -y ca-certificates fonts-liberation libasound2 libatk-bridge2.0-0 \
  libatk1.0-0 libc6 libcairo2 libcups2 libdbus-1-3 libexpat1 libfontconfig1 \
  libgbm1 libgcc1 libglib2.0-0 libgtk-3-0 libnspr4 libnss3 libpango-1.0-0 \
  libpangocairo-1.0-0 libx11-6 libx11-xcb1 libxcb1 libxcomposite1 libxcursor1 \
  libxdamage1 libxext6 libxfixes3 libxi6 libxrandr2 libxrender1 libxss1 \
  libxtst6 lsb-release wget xdg-utils
```

## 5. Set up MongoDB Atlas

1. Create a free cluster (M0 tier) at https://cloud.mongodb.com
2. Under **Database Access**, create a database user with a strong password
3. Under **Network Access**, add your VPS's public IP address (or `0.0.0.0/0`
   while testing, then lock it down to the VPS IP once things work)
4. Click **Connect → Drivers**, copy the connection string — it looks like
   `mongodb+srv://<user>:<password>@cluster0.xxxxx.mongodb.net/`
5. Append your database name to it, e.g. `.../resumebuilder?retryWrites=true&w=majority`

## 6. Get the code onto the server

If you've pushed this repo to GitHub:

```bash
cd ~
git clone https://github.com/yourusername/resume-builder.git
cd resume-builder
```

Otherwise, zip the `resume-builder/` folder locally and `scp` it up:

```bash
# from your local machine
scp resume-builder.zip deploy@your-vps-ip:~
# on the server
unzip resume-builder.zip
```

## 7. Configure and start the backend

```bash
cd ~/resume-builder/backend
cp .env.example .env
nano .env   # fill in MONGO_URI, JWT_SECRET, RAZORPAY_* (see the Razorpay guide below)
```

Generate a strong `JWT_SECRET` with:

```bash
node -e "console.log(require('crypto').randomBytes(48).toString('hex'))"
```

Install and start:

```bash
npm ci --omit=dev
pm2 start src/server.js --name resume-api
pm2 save
pm2 startup   # run the command it prints, so PM2 survives a reboot
```

Check it's alive: `pm2 logs resume-api` and `curl localhost:5000/api/health`.

## 8. Build and deploy the frontend

The frontend is a static React build — Nginx will serve the files directly,
no Node process needed for it.

```bash
cd ~/resume-builder/frontend
echo "VITE_API_URL=https://yourdomain.com/api" > .env.production
npm ci
npm run build   # outputs to frontend/dist
```

## 9. Configure Nginx

Create `/etc/nginx/sites-available/resumeforge`:

```nginx
server {
    listen 80;
    server_name yourdomain.com www.yourdomain.com;

    root /home/deploy/resume-builder/frontend/dist;
    index index.html;

    # React Router — let the app handle client-side routes
    location / {
        try_files $uri $uri/ /index.html;
    }

    # Proxy API calls to the Node backend running on PM2
    location /api/ {
        proxy_pass http://localhost:5000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_cache_bypass $http_upgrade;
        client_max_body_size 5m;
    }
}
```

Enable it:

```bash
sudo ln -s /etc/nginx/sites-available/resumeforge /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx
```

## 10. Turn on HTTPS

```bash
sudo certbot --nginx -d yourdomain.com -d www.yourdomain.com
```

Certbot edits the Nginx config to redirect HTTP → HTTPS and auto-renews the
certificate. Confirm auto-renewal works with `sudo certbot renew --dry-run`.

## 11. Set up Razorpay

1. Sign up at https://razorpay.com and complete KYC. You'll need: PAN, Aadhaar,
   a bank account (a personal account is fine for a sole proprietor; a
   registered company needs a current account in the company's name), and —
   once you're registered for GST — your GST certificate. **KYC review can
   take a few days, so start this well before you plan to launch.** Razorpay's
   own checklist is here: https://razorpay.com/docs/payments/account-activation-support/
2. While waiting for approval, build and test everything in **Test Mode**
   (Razorpay gives you test API keys immediately, no KYC required).
3. Create two **Plans** under Dashboard → Subscriptions → Plans: one monthly,
   one quarterly, with the price you want to charge. Copy each Plan's ID into
   `RAZORPAY_PLAN_MONTHLY` / `RAZORPAY_PLAN_QUARTERLY` in your `.env`.
4. Under Dashboard → Webhooks, add a webhook pointing to
   `https://yourdomain.com/api/subscriptions/webhook`, subscribed to the
   `subscription.*` and `payment.*` events. Set a webhook secret and put the
   same value in `RAZORPAY_WEBHOOK_SECRET`.
5. Once KYC is approved, switch the Dashboard to **Live Mode**, generate live
   API keys, update your `.env` with them, and `pm2 restart resume-api`.

## 12. Go-live checklist

- [ ] HTTPS is active and the site loads on `https://yourdomain.com`
- [ ] `pm2 startup` and `pm2 save` are configured so the API survives a reboot
- [ ] `.env` is **not** committed to git (it's already in `.gitignore`)
- [ ] You've fired a test webhook from the Razorpay dashboard and see it logged
- [ ] Terms of Service, Privacy Policy, and Refund/Cancellation Policy pages
      are live and linked (Razorpay checks for these during KYC, and you need
      them regardless)
- [ ] You've walked through the full journey yourself: register → create a
      resume → fill it in → subscribe with a real (or Razorpay test) card →
      download a PDF and a Word file
- [ ] Hostinger's free weekly VPS backups are enabled (hPanel → VPS → Backups)

## Keeping it running

- `pm2 logs resume-api` — tail backend logs
- `pm2 restart resume-api` — after any backend code or `.env` change
- To ship a frontend update: `git pull`, `npm run build` in `frontend/`, no
  restart needed — Nginx just serves the new static files
- Set up a simple uptime monitor (e.g. UptimeRobot's free tier) pinging
  `/api/health` so you hear about downtime before your customers do
