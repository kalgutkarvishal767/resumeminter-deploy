// Turns a Resume document + a Template config into a full, self-contained
// HTML document (inline <style>, Google Fonts <link>). This exact HTML is:
//   1. Rendered inside an <iframe srcDoc="..."> on the frontend for the live,
//      pixel-accurate preview, and
//   2. Fed to Puppeteer on the backend to produce the downloadable PDF.
// Using one renderer for both guarantees "what you see is what you download".
//
// This file must stay framework-agnostic and dependency-free (no React, no
// Node built-ins) so it can be imported unmodified by both the Vite frontend
// and the Node backend.

import { LAYOUTS, GOOGLE_FONTS, fontStack } from './templateRegistry.js';

function esc(value) {
  if (value === null || value === undefined) return '';
  return String(value)
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&#39;');
}

function dateRange(item) {
  const start = esc(item.startDate);
  const end = item.current ? 'Present' : esc(item.endDate);
  if (!start && !end) return '';
  return `${start}${start && end ? ' – ' : ''}${end}`;
}

function bulletsHtml(bullets) {
  const clean = (bullets || []).filter((b) => b && b.trim());
  if (!clean.length) return '';
  return `<ul class="bullets">${clean.map((b) => `<li>${esc(b)}</li>`).join('')}</ul>`;
}

// ---- individual section renderers (each returns '' if there's nothing to show) ----

function sectionSummary(resume) {
  if (!resume.summary || !resume.summary.trim()) return '';
  return `
    <section class="section">
      <h2 class="section-title">Summary</h2>
      <p class="summary-text">${esc(resume.summary)}</p>
    </section>`;
}

function sectionExperience(resume) {
  const items = resume.experience || [];
  if (!items.length) return '';
  return `
    <section class="section">
      <h2 class="section-title">Experience</h2>
      ${items
        .map(
          (job) => `
        <div class="entry">
          <div class="entry-head">
            <div>
              <div class="entry-title">${esc(job.role)}</div>
              <div class="entry-subtitle">${esc(job.company)}${job.location ? ` &middot; ${esc(job.location)}` : ''}</div>
            </div>
            <div class="entry-date">${dateRange(job)}</div>
          </div>
          ${bulletsHtml(job.bullets)}
        </div>`
        )
        .join('')}
    </section>`;
}

function sectionEducation(resume) {
  const items = resume.education || [];
  if (!items.length) return '';
  return `
    <section class="section">
      <h2 class="section-title">Education</h2>
      ${items
        .map(
          (ed) => `
        <div class="entry">
          <div class="entry-head">
            <div>
              <div class="entry-title">${esc(ed.degree)}${ed.field ? `, ${esc(ed.field)}` : ''}</div>
              <div class="entry-subtitle">${esc(ed.school)}${ed.location ? ` &middot; ${esc(ed.location)}` : ''}</div>
            </div>
            <div class="entry-date">${dateRange(ed)}</div>
          </div>
          ${ed.grade ? `<div class="entry-meta">${esc(ed.grade)}</div>` : ''}
        </div>`
        )
        .join('')}
    </section>`;
}

function sectionProjects(resume) {
  const items = resume.projects || [];
  if (!items.length) return '';
  return `
    <section class="section">
      <h2 class="section-title">Projects</h2>
      ${items
        .map(
          (p) => `
        <div class="entry">
          <div class="entry-head">
            <div class="entry-title">${esc(p.name)}${p.link ? ` &mdash; <span class="entry-link">${esc(p.link)}</span>` : ''}</div>
          </div>
          ${p.description ? `<p class="entry-desc">${esc(p.description)}</p>` : ''}
          ${bulletsHtml(p.bullets)}
        </div>`
        )
        .join('')}
    </section>`;
}

function sectionCertifications(resume) {
  const items = resume.certifications || [];
  if (!items.length) return '';
  return `
    <section class="section">
      <h2 class="section-title">Certifications</h2>
      ${items
        .map(
          (c) => `
        <div class="entry entry-compact">
          <span class="entry-title">${esc(c.name)}</span>
          ${c.issuer ? `<span class="entry-subtitle"> &middot; ${esc(c.issuer)}</span>` : ''}
          ${c.date ? `<span class="entry-date">${esc(c.date)}</span>` : ''}
        </div>`
        )
        .join('')}
    </section>`;
}

function sectionSkills(resume, asTags = true) {
  const items = (resume.skills || []).filter(Boolean);
  if (!items.length) return '';
  if (asTags) {
    return `
      <section class="section">
        <h2 class="section-title">Skills</h2>
        <div class="tags">${items.map((s) => `<span class="tag">${esc(s)}</span>`).join('')}</div>
      </section>`;
  }
  return `
    <section class="section">
      <h2 class="section-title">Skills</h2>
      <p class="plain-list">${items.map(esc).join(', ')}</p>
    </section>`;
}

function sectionLanguages(resume) {
  const items = (resume.languages || []).filter((l) => l && l.name);
  if (!items.length) return '';
  return `
    <section class="section">
      <h2 class="section-title">Languages</h2>
      <p class="plain-list">${items.map((l) => `${esc(l.name)}${l.level ? ` (${esc(l.level)})` : ''}`).join(', ')}</p>
    </section>`;
}

function sectionContact(resume) {
  const p = resume.personalInfo || {};
  const rows = [
    p.email && `<div class="contact-row">${esc(p.email)}</div>`,
    p.phone && `<div class="contact-row">${esc(p.phone)}</div>`,
    p.location && `<div class="contact-row">${esc(p.location)}</div>`,
    p.website && `<div class="contact-row">${esc(p.website)}</div>`,
    p.linkedin && `<div class="contact-row">${esc(p.linkedin)}</div>`
  ].filter(Boolean);
  if (!rows.length) return '';
  return `<section class="section"><h2 class="section-title">Contact</h2>${rows.join('')}</section>`;
}

const SECTION_RENDERERS = {
  summary: sectionSummary,
  experience: sectionExperience,
  education: sectionEducation,
  skills: sectionSkills,
  projects: sectionProjects,
  certifications: sectionCertifications,
  languages: sectionLanguages
};

function renderOrderedSections(resume, order, exclude = []) {
  const seq = (order && order.length ? order : Object.keys(SECTION_RENDERERS)).filter((s) => !exclude.includes(s));
  return seq.map((key) => (SECTION_RENDERERS[key] ? SECTION_RENDERERS[key](resume) : '')).join('');
}

function headerBlock(resume, { withPhoto = false } = {}) {
  const p = resume.personalInfo || {};
  const contactLine = [p.email, p.phone, p.location, p.website, p.linkedin]
    .filter(Boolean)
    .map(esc)
    .join(' &nbsp;&bull;&nbsp; ');
  return `
    <header class="header">
      ${withPhoto && p.photoUrl ? `<img class="photo" src="${esc(p.photoUrl)}" alt="" />` : ''}
      <div>
        <h1 class="name">${esc(p.fullName) || 'Your Name'}</h1>
        <div class="job-title">${esc(p.jobTitle)}</div>
        ${contactLine ? `<div class="contact-line">${contactLine}</div>` : ''}
      </div>
    </header>`;
}

// ---- layout composers ----

function layoutSingleColumn(resume) {
  return `
    <div class="page single-column">
      ${headerBlock(resume)}
      <div class="body">${renderOrderedSections(resume, resume.sectionOrder)}</div>
    </div>`;
}

function layoutSidebar(resume, side) {
  const sidebarSections = `${sectionContact(resume)}${sectionSkills(resume)}${sectionLanguages(resume)}${sectionCertifications(resume)}`;
  const mainSections = renderOrderedSections(resume, resume.sectionOrder, ['skills', 'languages', 'certifications']);
  const sidebarEl = `<aside class="sidebar">${sidebarSections}</aside>`;
  const mainEl = `<main class="main">${headerBlock(resume, { withPhoto: true })}${mainSections}</main>`;
  return `
    <div class="page sidebar-layout sidebar-${side}">
      ${side === 'left' ? sidebarEl + mainEl : mainEl + sidebarEl}
    </div>`;
}

function layoutTwoColumnBody(resume) {
  const left = renderOrderedSections(resume, ['summary', 'experience', 'projects']);
  const right = `${sectionContact(resume)}${renderOrderedSections(resume, ['education', 'skills', 'certifications', 'languages'])}`;
  return `
    <div class="page two-column-body">
      ${headerBlock(resume)}
      <div class="columns">
        <div class="col-left">${left}</div>
        <div class="col-right">${right}</div>
      </div>
    </div>`;
}

function layoutTimeline(resume) {
  const items = resume.experience || [];
  const timelineHtml = items.length
    ? `
    <section class="section">
      <h2 class="section-title">Experience</h2>
      <div class="timeline">
        ${items
          .map(
            (job) => `
          <div class="timeline-item">
            <div class="timeline-dot"></div>
            <div class="timeline-content">
              <div class="entry-head">
                <div>
                  <div class="entry-title">${esc(job.role)}</div>
                  <div class="entry-subtitle">${esc(job.company)}${job.location ? ` &middot; ${esc(job.location)}` : ''}</div>
                </div>
                <div class="entry-date">${dateRange(job)}</div>
              </div>
              ${bulletsHtml(job.bullets)}
            </div>
          </div>`
          )
          .join('')}
      </div>
    </section>`
    : '';

  const rest = renderOrderedSections(resume, resume.sectionOrder, ['experience', 'summary']);
  return `
    <div class="page timeline-layout">
      ${headerBlock(resume)}
      <div class="body">${sectionSummary(resume)}${timelineHtml}${rest}</div>
    </div>`;
}

function layoutCompactMinimal(resume) {
  return `
    <div class="page compact-minimal">
      ${headerBlock(resume)}
      <div class="body">${renderOrderedSections(resume, resume.sectionOrder)}</div>
    </div>`;
}

function layoutCreativeHeader(resume, accentColor) {
  return `
    <div class="page creative-header">
      <header class="creative-band" style="background:${esc(accentColor)}">
        ${headerBlock(resume, { withPhoto: true })}
      </header>
      <div class="body">${renderOrderedSections(resume, resume.sectionOrder)}</div>
    </div>`;
}

const LAYOUT_COMPOSERS = {
  [LAYOUTS.SINGLE_COLUMN]: (r) => layoutSingleColumn(r),
  [LAYOUTS.SIDEBAR_LEFT]: (r) => layoutSidebar(r, 'left'),
  [LAYOUTS.SIDEBAR_RIGHT]: (r) => layoutSidebar(r, 'right'),
  [LAYOUTS.TWO_COLUMN_BODY]: (r) => layoutTwoColumnBody(r),
  [LAYOUTS.TIMELINE]: (r) => layoutTimeline(r),
  [LAYOUTS.COMPACT_MINIMAL]: (r) => layoutCompactMinimal(r),
  [LAYOUTS.CREATIVE_HEADER]: (r, accent) => layoutCreativeHeader(r, accent)
};

function baseCss(accentColor, headingFontKey, bodyFontKey, density, sidebarDark) {
  const heading = fontStack(headingFontKey);
  const body = fontStack(bodyFontKey);
  const tight = density === 'compact';
  return `
    :root {
      --accent: ${accentColor};
      --text: #1f2937;
      --muted: #6b7280;
      --border: #e5e7eb;
    }
    * { box-sizing: border-box; }
    html, body { margin: 0; padding: 0; }
    body {
      font-family: ${body};
      color: var(--text);
      font-size: ${tight ? '12.5px' : '13.5px'};
      line-height: ${tight ? 1.35 : 1.5};
      background: #fff;
    }
    .page { width: 794px; min-height: 1123px; margin: 0 auto; padding: ${tight ? '32px 40px' : '48px 56px'}; }
    h1, h2, h3 { font-family: ${heading}; margin: 0; }
    .header { display: flex; gap: 16px; align-items: center; margin-bottom: ${tight ? '14px' : '22px'}; }
    .photo { width: 76px; height: 76px; border-radius: 50%; object-fit: cover; flex-shrink: 0; }
    .name { font-size: ${tight ? '24px' : '30px'}; font-weight: 700; color: var(--text); }
    .job-title { font-size: ${tight ? '13px' : '15px'}; color: var(--accent); font-weight: 600; margin-top: 2px; }
    .contact-line { font-size: 11.5px; color: var(--muted); margin-top: 6px; }
    .section { margin-bottom: ${tight ? '12px' : '18px'}; }
    .section-title {
      font-size: ${tight ? '12px' : '13px'};
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.06em;
      color: var(--accent);
      border-bottom: 1.5px solid var(--border);
      padding-bottom: 4px;
      margin-bottom: ${tight ? '8px' : '10px'};
    }
    .summary-text { margin: 0; color: var(--text); }
    .entry { margin-bottom: ${tight ? '8px' : '12px'}; }
    .entry-compact { display: flex; gap: 6px; align-items: baseline; flex-wrap: wrap; margin-bottom: 6px; }
    .entry-head { display: flex; justify-content: space-between; gap: 12px; align-items: baseline; }
    .entry-title { font-weight: 700; font-size: ${tight ? '12.5px' : '13.5px'}; }
    .entry-subtitle { color: var(--muted); font-size: 12px; }
    .entry-date { color: var(--muted); font-size: 11.5px; white-space: nowrap; }
    .entry-meta { color: var(--muted); font-size: 11.5px; margin-top: 2px; }
    .entry-desc { margin: 4px 0; }
    .entry-link { color: var(--accent); }
    .bullets { margin: 6px 0 0 0; padding-left: 18px; }
    .bullets li { margin-bottom: 3px; }
    .tags { display: flex; flex-wrap: wrap; gap: 6px; }
    .tag { background: color-mix(in srgb, var(--accent) 12%, white); color: var(--accent); border-radius: 999px; padding: 3px 10px; font-size: 11px; font-weight: 600; }
    .plain-list { margin: 0; }

    /* sidebar layout */
    .sidebar-layout { display: flex; gap: 0; padding: 0; width: 794px; min-height: 1123px; }
    .sidebar-layout .sidebar {
      width: 260px; padding: ${tight ? '32px 22px' : '44px 28px'};
      background: ${sidebarDark ? '#111827' : 'color-mix(in srgb, var(--accent) 6%, white)'};
      color: ${sidebarDark ? '#e5e7eb' : 'var(--text)'};
    }
    .sidebar-layout .sidebar .section-title { color: ${sidebarDark ? '#fff' : 'var(--accent)'}; border-bottom-color: ${sidebarDark ? 'rgba(255,255,255,0.2)' : 'var(--border)'}; }
    .sidebar-layout .sidebar .contact-row { font-size: 11px; margin-bottom: 4px; word-break: break-word; }
    .sidebar-layout .main { flex: 1; padding: ${tight ? '32px 32px' : '44px 40px'}; }
    .sidebar-layout .main .header { flex-direction: row; }

    /* two-column-body layout */
    .two-column-body .columns { display: flex; gap: 28px; margin-top: 8px; }
    .two-column-body .col-left { flex: 1.4; }
    .two-column-body .col-right { flex: 1; border-left: 1px solid var(--border); padding-left: 24px; }

    /* timeline layout */
    .timeline { position: relative; margin-left: 6px; padding-left: 18px; border-left: 2px solid var(--border); }
    .timeline-item { position: relative; margin-bottom: ${tight ? '10px' : '16px'}; }
    .timeline-dot { position: absolute; left: -24px; top: 3px; width: 10px; height: 10px; border-radius: 50%; background: var(--accent); }

    /* creative header layout */
    .creative-header .creative-band { padding: ${tight ? '28px 40px' : '40px 56px'}; }
    .creative-header .creative-band .header { margin-bottom: 0; }
    .creative-header .creative-band .name,
    .creative-header .creative-band .job-title,
    .creative-header .creative-band .contact-line { color: #fff; }
    .creative-header .creative-band .job-title { opacity: 0.92; }
    .creative-header .creative-band .photo { border: 3px solid rgba(255,255,255,0.6); }
    .creative-header .body { padding: ${tight ? '24px 40px' : '32px 56px'}; }

    @media print {
      .page, .sidebar-layout { width: auto; min-height: 0; }
      body { -webkit-print-color-adjust: exact; print-color-adjust: exact; }
    }
  `;
}

export function renderResumeHTML(resume, template) {
  const accentColor = resume.accentColor || template.defaultAccentColor;
  const composer = LAYOUT_COMPOSERS[template.layout] || LAYOUT_COMPOSERS[LAYOUTS.SINGLE_COLUMN];
  const bodyHtml = composer(resume, accentColor);
  const css = baseCss(accentColor, template.headingFont, template.bodyFont, resume.density || template.density, template.sidebarDark);
  const fontFamilies = [GOOGLE_FONTS[template.headingFont], GOOGLE_FONTS[template.bodyFont]].filter(Boolean);
  const uniqueFamilies = [...new Set(fontFamilies)];
  const fontsHref = uniqueFamilies.length
    ? `https://fonts.googleapis.com/css2?${uniqueFamilies.map((f) => `family=${f}`).join('&')}&display=swap`
    : null;

  return `<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<title>${esc((resume.personalInfo && resume.personalInfo.fullName) || 'Resume')}</title>
${fontsHref ? `<link rel="preconnect" href="https://fonts.googleapis.com"><link rel="preconnect" href="https://fonts.gstatic.com" crossorigin><link href="${fontsHref}" rel="stylesheet">` : ''}
<style>${css}</style>
</head>
<body>
${bodyHtml}
</body>
</html>`;
}
