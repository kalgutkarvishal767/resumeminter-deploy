// Gates a route behind an active paid subscription.
// Free users can still build/preview resumes; only export (PDF/DOCX) is gated,
// which mirrors common resume-builder monetization ("free to build, pay to download").
export function requireActiveSubscription(req, res, next) {
  const user = req.user;
  if (!user || !user.hasActiveSubscription()) {
    return res.status(402).json({
      error: 'An active subscription is required to download resumes.',
      code: 'SUBSCRIPTION_REQUIRED'
    });
  }
  next();
}
