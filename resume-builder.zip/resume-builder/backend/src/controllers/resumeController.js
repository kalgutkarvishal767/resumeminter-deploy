import Resume from '../models/Resume.js';
import { getTemplateById } from '../templates/templateRegistry.js';

const FREE_RESUME_LIMIT = 1; // non-subscribers can keep 1 resume in progress

export async function listResumes(req, res) {
  const resumes = await Resume.find({ user: req.user._id }).sort({ updatedAt: -1 });
  res.json({ resumes });
}

export async function getResume(req, res) {
  const resume = await Resume.findOne({ _id: req.params.id, user: req.user._id });
  if (!resume) return res.status(404).json({ error: 'Resume not found' });
  res.json({ resume });
}

export async function createResume(req, res) {
  const isSubscribed = req.user.hasActiveSubscription();
  if (!isSubscribed) {
    const count = await Resume.countDocuments({ user: req.user._id });
    if (count >= FREE_RESUME_LIMIT) {
      return res.status(402).json({
        error: `Free accounts are limited to ${FREE_RESUME_LIMIT} resume. Subscribe to create more.`,
        code: 'SUBSCRIPTION_REQUIRED'
      });
    }
  }

  const { title, templateId } = req.body;
  const template = getTemplateById(templateId) || getTemplateById('classic-01');

  const resume = new Resume({
    user: req.user._id,
    title: title || 'Untitled Resume',
    templateId: template.id,
    accentColor: template.defaultAccentColor
  });
  await resume.save();
  res.status(201).json({ resume });
}

export async function updateResume(req, res) {
  const resume = await Resume.findOne({ _id: req.params.id, user: req.user._id });
  if (!resume) return res.status(404).json({ error: 'Resume not found' });

  const allowedFields = [
    'title',
    'templateId',
    'accentColor',
    'fontFamily',
    'personalInfo',
    'summary',
    'experience',
    'education',
    'skills',
    'languages',
    'projects',
    'certifications',
    'sectionOrder',
    'sectionStyles'
  ];

  for (const field of allowedFields) {
    if (req.body[field] !== undefined) {
      resume[field] = req.body[field];
    }
  }

  await resume.save();
  res.json({ resume });
}

export async function deleteResume(req, res) {
  const resume = await Resume.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!resume) return res.status(404).json({ error: 'Resume not found' });
  res.json({ success: true });
}

export async function duplicateResume(req, res) {
  const isSubscribed = req.user.hasActiveSubscription();
  if (!isSubscribed) {
    const count = await Resume.countDocuments({ user: req.user._id });
    if (count >= FREE_RESUME_LIMIT) {
      return res.status(402).json({
        error: `Free accounts are limited to ${FREE_RESUME_LIMIT} resume. Subscribe to create more.`,
        code: 'SUBSCRIPTION_REQUIRED'
      });
    }
  }

  const original = await Resume.findOne({ _id: req.params.id, user: req.user._id });
  if (!original) return res.status(404).json({ error: 'Resume not found' });

  const copy = original.toObject();
  delete copy._id;
  delete copy.createdAt;
  delete copy.updatedAt;
  copy.title = `${copy.title} (copy)`;

  const resume = new Resume(copy);
  await resume.save();
  res.status(201).json({ resume });
}
