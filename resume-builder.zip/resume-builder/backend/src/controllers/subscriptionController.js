import Subscription from '../models/Subscription.js';
import User from '../models/User.js';
import {
  getRazorpayClient,
  getPlanId,
  PLAN_CONFIG,
  verifyWebhookSignature,
  verifyCheckoutSignature
} from '../services/razorpayService.js';

export function getPlans(req, res) {
  res.json({
    plans: [
      { id: 'monthly', label: PLAN_CONFIG.monthly.label, priceHint: 'Billed every month. Cancel anytime.' },
      { id: 'quarterly', label: PLAN_CONFIG.quarterly.label, priceHint: 'Billed every 3 months. Best value.' }
    ]
  });
}

// Step 1: create a pending Razorpay subscription and hand its id to the
// frontend, which opens Razorpay Checkout to collect payment / mandate auth.
export async function createSubscription(req, res) {
  try {
    const { plan } = req.body;
    if (!PLAN_CONFIG[plan]) {
      return res.status(400).json({ error: 'plan must be "monthly" or "quarterly"' });
    }

    const razorpay = getRazorpayClient();
    const planId = getPlanId(plan);

    const rpSubscription = await razorpay.subscriptions.create({
      plan_id: planId,
      customer_notify: 1,
      total_count: PLAN_CONFIG[plan].totalCount,
      notes: { userId: req.user._id.toString(), plan }
    });

    await Subscription.create({
      user: req.user._id,
      razorpaySubscriptionId: rpSubscription.id,
      plan,
      status: 'created'
    });

    res.json({
      subscriptionId: rpSubscription.id,
      razorpayKeyId: process.env.RAZORPAY_KEY_ID
    });
  } catch (err) {
    console.error('[subscription] create error', err);
    res.status(500).json({ error: 'Failed to start subscription checkout' });
  }
}

// Step 2: the frontend calls this right after Razorpay Checkout succeeds, as
// a fast optimistic confirmation. The webhook (below) remains the source of
// truth in case the user closes the tab before this call completes.
export async function confirmSubscription(req, res) {
  try {
    const { razorpay_payment_id, razorpay_subscription_id, razorpay_signature } = req.body;
    if (!razorpay_payment_id || !razorpay_subscription_id || !razorpay_signature) {
      return res.status(400).json({ error: 'Missing checkout confirmation fields' });
    }

    const valid = verifyCheckoutSignature({ razorpay_payment_id, razorpay_subscription_id, razorpay_signature });
    if (!valid) {
      return res.status(400).json({ error: 'Signature verification failed' });
    }

    const sub = await Subscription.findOne({ razorpaySubscriptionId: razorpay_subscription_id, user: req.user._id });
    if (!sub) return res.status(404).json({ error: 'Subscription record not found' });

    sub.status = 'active';
    sub.lastPaymentId = razorpay_payment_id;
    await sub.save();

    const periodEnd = new Date();
    periodEnd.setDate(periodEnd.getDate() + (sub.plan === 'quarterly' ? 92 : 31));

    await User.findByIdAndUpdate(req.user._id, {
      subscription: {
        status: 'active',
        plan: sub.plan,
        currentPeriodEnd: periodEnd,
        razorpaySubscriptionId: sub.razorpaySubscriptionId
      }
    });

    res.json({ success: true });
  } catch (err) {
    console.error('[subscription] confirm error', err);
    res.status(500).json({ error: 'Failed to confirm subscription' });
  }
}

export async function cancelSubscription(req, res) {
  try {
    const user = req.user;
    if (!user.subscription.razorpaySubscriptionId) {
      return res.status(400).json({ error: 'No active subscription to cancel' });
    }

    const razorpay = getRazorpayClient();
    await razorpay.subscriptions.cancel(user.subscription.razorpaySubscriptionId, {
      cancel_at_cycle_end: true
    });

    await Subscription.findOneAndUpdate(
      { razorpaySubscriptionId: user.subscription.razorpaySubscriptionId },
      { status: 'cancelled' }
    );

    res.json({ success: true, message: 'Subscription will be cancelled at the end of the current billing period.' });
  } catch (err) {
    console.error('[subscription] cancel error', err);
    res.status(500).json({ error: 'Failed to cancel subscription' });
  }
}

// Razorpay webhook — the source of truth for subscription lifecycle events
// (activation, recurring charges, failures, cancellations). Configure this
// URL (POST /api/subscriptions/webhook) in the Razorpay Dashboard under
// Settings > Webhooks, with the same secret as RAZORPAY_WEBHOOK_SECRET.
export async function handleWebhook(req, res) {
  try {
    const signature = req.headers['x-razorpay-signature'];
    const valid = verifyWebhookSignature(req.body, signature); // req.body is a raw Buffer here
    if (!valid) {
      return res.status(400).json({ error: 'Invalid webhook signature' });
    }

    const payload = JSON.parse(req.body.toString('utf8'));
    const event = payload.event;
    const entity = payload.payload?.subscription?.entity || payload.payload?.payment?.entity;
    const subscriptionId = payload.payload?.subscription?.entity?.id;

    if (subscriptionId) {
      const sub = await Subscription.findOne({ razorpaySubscriptionId: subscriptionId });
      if (sub) {
        sub.rawEvents.push({ event, payload, receivedAt: new Date() });

        let userUpdate = null;

        if (event === 'subscription.activated' || event === 'subscription.charged') {
          sub.status = 'active';
          const currentEnd = entity?.current_end ? new Date(entity.current_end * 1000) : null;
          if (currentEnd) sub.currentEnd = currentEnd;
          userUpdate = {
            'subscription.status': 'active',
            'subscription.plan': sub.plan,
            'subscription.currentPeriodEnd': currentEnd || sub.currentEnd,
            'subscription.razorpaySubscriptionId': subscriptionId
          };
        } else if (event === 'subscription.pending' || event === 'subscription.halted') {
          sub.status = 'past_due';
          userUpdate = { 'subscription.status': 'past_due' };
        } else if (event === 'subscription.cancelled' || event === 'subscription.completed') {
          sub.status = event === 'subscription.completed' ? 'completed' : 'cancelled';
          userUpdate = { 'subscription.status': 'cancelled' };
        }

        await sub.save();
        if (userUpdate) {
          await User.findByIdAndUpdate(sub.user, { $set: userUpdate });
        }
      }
    }

    res.json({ received: true });
  } catch (err) {
    console.error('[subscription] webhook error', err);
    res.status(500).json({ error: 'Webhook processing failed' });
  }
}
