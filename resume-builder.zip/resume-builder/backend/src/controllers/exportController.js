import Resume from '../models/Resume.js';
import { generateResumePDF } from '../services/pdfService.js';
import { buildResumeDocx } from '../services/docxService.js';

function safeFilename(title) {
  return (title || 'resume').replace(/[^a-z0-9\-_]+/gi, '_').slice(0, 60);
}

export async function exportPdf(req, res) {
  try {
    const resume = await Resume.findOne({ _id: req.params.id, user: req.user._id });
    if (!resume) return res.status(404).json({ error: 'Resume not found' });

    const pdfBuffer = await generateResumePDF(resume);
    res.setHeader('Content-Type', 'application/pdf');
    res.setHeader('Content-Disposition', `attachment; filename="${safeFilename(resume.title)}.pdf"`);
    res.send(pdfBuffer);
  } catch (err) {
    console.error('[export] pdf error', err);
    res.status(500).json({ error: 'Failed to generate PDF' });
  }
}

export async function exportDocx(req, res) {
  try {
    const resume = await Resume.findOne({ _id: req.params.id, user: req.user._id });
    if (!resume) return res.status(404).json({ error: 'Resume not found' });

    const buffer = await buildResumeDocx(resume);
    res.setHeader('Content-Type', 'application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    res.setHeader('Content-Disposition', `attachment; filename="${safeFilename(resume.title)}.docx"`);
    res.send(buffer);
  } catch (err) {
    console.error('[export] docx error', err);
    res.status(500).json({ error: 'Failed to generate Word document' });
  }
}
