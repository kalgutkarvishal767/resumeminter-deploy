// Backend re-export of the shared, framework-agnostic template registry.
// Keeping a single source of truth in /shared avoids the frontend and
// backend ever disagreeing about what a template looks like.
export * from '../../../shared/templateRegistry.js';
