import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { getPlans, createSubscription, confirmSubscription, cancelSubscription } from '../controllers/subscriptionController.js';

// NOTE: the Razorpay webhook route lives directly in server.js (not here)
// because it needs the raw request body for HMAC signature verification,
// and must be mounted BEFORE the global express.json() middleware. Every
// other route in this file needs parsed JSON, so this router is mounted
// AFTER express.json() instead. See server.js for the exact ordering.

const router = Router();

router.get('/plans', getPlans);
router.post('/create', requireAuth, createSubscription);
router.post('/confirm', requireAuth, confirmSubscription);
router.post('/cancel', requireAuth, cancelSubscription);

export default router;
