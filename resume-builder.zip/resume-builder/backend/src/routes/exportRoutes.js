import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { requireActiveSubscription } from '../middleware/subscription.js';
import { exportPdf, exportDocx } from '../controllers/exportController.js';

const router = Router();

router.use(requireAuth);
router.use(requireActiveSubscription); // downloads are the paid feature

router.get('/:id/pdf', exportPdf);
router.get('/:id/docx', exportDocx);

export default router;
