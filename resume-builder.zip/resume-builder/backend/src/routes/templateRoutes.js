import { Router } from 'express';
import { listTemplateSummaries } from '../templates/templateRegistry.js';

const router = Router();

router.get('/', (req, res) => {
  res.json({ templates: listTemplateSummaries() });
});

export default router;
