import puppeteer from 'puppeteer';
import { renderResumeHTML } from '../../../shared/resumeHtmlRenderer.js';
import { getTemplateById } from '../templates/templateRegistry.js';

let browserPromise = null;

// Reuse a single headless Chrome instance across requests instead of
// launching a new one every time — launching is the slowest part of PDF
// generation and this matters once you have concurrent users.
function getBrowser() {
  if (!browserPromise) {
    browserPromise = puppeteer.launch({
      headless: true,
      args: ['--no-sandbox', '--disable-setuid-sandbox']
    });
  }
  return browserPromise;
}

export async function generateResumePDF(resume) {
  const template = getTemplateById(resume.templateId);
  if (!template) {
    throw new Error(`Unknown template: ${resume.templateId}`);
  }

  const html = renderResumeHTML(resume.toObject ? resume.toObject() : resume, template);

  const browser = await getBrowser();
  const page = await browser.newPage();
  try {
    await page.setContent(html, { waitUntil: 'networkidle0' });
    // Make sure webfonts are actually painted before printing, otherwise
    // Puppeteer can rasterize with a fallback font on the first page.
    await page.evaluateHandle('document.fonts.ready');

    const pdfBuffer = await page.pdf({
      format: 'A4',
      printBackground: true,
      preferCSSPageSize: false
    });
    // Puppeteer can return a Uint8Array rather than a Node Buffer depending
    // on version; Express's res.send() needs a real Buffer or it will try to
    // JSON-serialize the raw byte array instead of sending binary PDF data.
    return Buffer.from(pdfBuffer);
  } finally {
    await page.close();
  }
}

export async function closeBrowser() {
  if (browserPromise) {
    const browser = await browserPromise;
    await browser.close();
    browserPromise = null;
  }
}
