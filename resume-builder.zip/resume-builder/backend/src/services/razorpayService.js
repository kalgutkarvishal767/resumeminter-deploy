import Razorpay from 'razorpay';
import crypto from 'crypto';

let client = null;

export function getRazorpayClient() {
  if (!client) {
    if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
      throw new Error('Razorpay keys are not configured');
    }
    client = new Razorpay({
      key_id: process.env.RAZORPAY_KEY_ID,
      key_secret: process.env.RAZORPAY_KEY_SECRET
    });
  }
  return client;
}

export const PLAN_CONFIG = {
  monthly: {
    envKey: 'RAZORPAY_PLAN_MONTHLY',
    label: 'Monthly',
    // total_count = number of billing cycles Razorpay will attempt before the
    // subscription naturally ends; a large number effectively means "until
    // cancelled". Adjust to taste.
    totalCount: 120
  },
  quarterly: {
    envKey: 'RAZORPAY_PLAN_QUARTERLY',
    label: 'Quarterly',
    totalCount: 40
  }
};

export function getPlanId(plan) {
  const config = PLAN_CONFIG[plan];
  if (!config) throw new Error(`Unknown plan: ${plan}`);
  const planId = process.env[config.envKey];
  if (!planId) throw new Error(`${config.envKey} is not set — create the plan in the Razorpay dashboard first`);
  return planId;
}

export function verifyWebhookSignature(rawBody, signatureHeader) {
  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_WEBHOOK_SECRET)
    .update(rawBody)
    .digest('hex');
  return expected === signatureHeader;
}

export function verifyCheckoutSignature({ razorpay_payment_id, razorpay_subscription_id, razorpay_signature }) {
  const payload = `${razorpay_payment_id}|${razorpay_subscription_id}`;
  const expected = crypto
    .createHmac('sha256', process.env.RAZORPAY_KEY_SECRET)
    .update(payload)
    .digest('hex');
  return expected === razorpay_signature;
}
