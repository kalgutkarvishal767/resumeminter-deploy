import nodemailer from 'nodemailer';

// Lazily-created singleton transporter. If SMTP isn't configured (e.g. during
// local development, or before the site owner has set up an email account),
// we don't crash the app — we just log the email content/link to the server
// console so the flow can still be tested manually.
let transporter = null;
let loggedMissingConfig = false;

function getTransporter() {
  if (transporter) return transporter;

  const { SMTP_HOST, SMTP_PORT, SMTP_USER, SMTP_PASS } = process.env;
  if (!SMTP_HOST || !SMTP_USER || !SMTP_PASS) {
    return null;
  }

  transporter = nodemailer.createTransport({
    host: SMTP_HOST,
    port: Number(SMTP_PORT) || 587,
    secure: Number(SMTP_PORT) === 465,
    auth: { user: SMTP_USER, pass: SMTP_PASS }
  });
  return transporter;
}

export async function sendPasswordResetEmail(toEmail, resetUrl) {
  const t = getTransporter();
  const fromAddress = process.env.EMAIL_FROM || `Resume Minter <no-reply@resumeminter.com>`;

  if (!t) {
    if (!loggedMissingConfig) {
      console.warn(
        '[email] SMTP is not configured (SMTP_HOST/SMTP_USER/SMTP_PASS missing in .env). ' +
          'Password reset links will be printed here instead of emailed until it is set up.'
      );
      loggedMissingConfig = true;
    }
    console.log(`[email] Password reset link for ${toEmail}: ${resetUrl}`);
    return { delivered: false };
  }

  await t.sendMail({
    from: fromAddress,
    to: toEmail,
    subject: 'Reset your Resume Minter password',
    text: `We received a request to reset your Resume Minter password.\n\nReset it here (valid for 1 hour):\n${resetUrl}\n\nIf you didn't request this, you can safely ignore this email.`,
    html: `
      <div style="font-family:sans-serif;max-width:480px;margin:0 auto;padding:24px;">
        <h2 style="color:#7c3aed;">Reset your password</h2>
        <p>We received a request to reset your Resume Minter password. This link is valid for 1 hour.</p>
        <p style="margin:24px 0;">
          <a href="${resetUrl}" style="background:#7c3aed;color:#fff;padding:12px 24px;border-radius:9999px;text-decoration:none;font-weight:600;">
            Reset password
          </a>
        </p>
        <p style="color:#6b7280;font-size:13px;">If you didn't request this, you can safely ignore this email.</p>
      </div>
    `
  });

  return { delivered: true };
}
