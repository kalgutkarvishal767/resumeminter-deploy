import { Document, Packer, Paragraph, TextRun, HeadingLevel, AlignmentType, BorderStyle } from 'docx';

// Word export deliberately uses ONE clean, ATS-friendly format regardless of
// which visual template the user picked for their PDF/web preview.
// Rationale (worth keeping in mind if you extend this):
//   1. Applicant Tracking Systems parse .docx text, not CSS — the elaborate
//      sidebars/timelines/color-bands that make the PDF templates distinctive
//      often parse badly or lose ordering in Word/ATS parsers.
//      Recruiters and career advice sites consistently recommend a plain,
//      single-column .docx for this reason.
//   2. Faithfully re-implementing 7 visual layouts in OOXML (docx) would be a
//      large amount of brittle code for a format users mainly want for
//      "ATS compatibility", not visual fidelity.
// If you later want fully templated Word exports, the cleanest path is
// converting the same HTML used for PDF via a headless LibreOffice
// (`soffice --headless --convert-to docx`) instead of hand-building OOXML.

const HEADING_COLOR = '1f2937';

function heading(text, accentHex) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: { before: 240, after: 100 },
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: accentHex } },
    children: [new TextRun({ text: text.toUpperCase(), bold: true, color: accentHex, size: 22 })]
  });
}

function bulletParagraphs(bullets) {
  return (bullets || [])
    .filter((b) => b && b.trim())
    .map(
      (b) =>
        new Paragraph({
          bullet: { level: 0 },
          spacing: { after: 40 },
          children: [new TextRun({ text: b, size: 21 })]
        })
    );
}

export function buildResumeDocx(resume) {
  const p = resume.personalInfo || {};
  const accentHex = (resume.accentColor || '#2563eb').replace('#', '');
  const children = [];

  children.push(
    new Paragraph({
      alignment: AlignmentType.LEFT,
      spacing: { after: 40 },
      children: [new TextRun({ text: p.fullName || 'Your Name', bold: true, size: 40, color: HEADING_COLOR })]
    })
  );
  if (p.jobTitle) {
    children.push(
      new Paragraph({
        spacing: { after: 80 },
        children: [new TextRun({ text: p.jobTitle, italics: true, size: 24, color: accentHex })]
      })
    );
  }
  const contactBits = [p.email, p.phone, p.location, p.website, p.linkedin].filter(Boolean);
  if (contactBits.length) {
    children.push(
      new Paragraph({
        spacing: { after: 160 },
        children: [new TextRun({ text: contactBits.join('  |  '), size: 20, color: '6b7280' })]
      })
    );
  }

  if (resume.summary && resume.summary.trim()) {
    children.push(heading('Summary', accentHex));
    children.push(new Paragraph({ spacing: { after: 120 }, children: [new TextRun({ text: resume.summary, size: 21 })] }));
  }

  if ((resume.experience || []).length) {
    children.push(heading('Experience', accentHex));
    for (const job of resume.experience) {
      const dates = job.current ? `${job.startDate || ''} – Present` : `${job.startDate || ''} – ${job.endDate || ''}`;
      children.push(
        new Paragraph({
          spacing: { before: 100 },
          children: [
            new TextRun({ text: `${job.role || ''}`, bold: true, size: 22 }),
            new TextRun({ text: job.company ? `  —  ${job.company}` : '', size: 22 }),
            new TextRun({ text: dates ? `   (${dates})` : '', size: 20, color: '6b7280', italics: true })
          ]
        })
      );
      children.push(...bulletParagraphs(job.bullets));
    }
  }

  if ((resume.education || []).length) {
    children.push(heading('Education', accentHex));
    for (const ed of resume.education) {
      const dates = `${ed.startDate || ''} – ${ed.endDate || ''}`;
      children.push(
        new Paragraph({
          spacing: { before: 80, after: 40 },
          children: [
            new TextRun({ text: `${ed.degree || ''}${ed.field ? `, ${ed.field}` : ''}`, bold: true, size: 22 }),
            new TextRun({ text: ed.school ? `  —  ${ed.school}` : '', size: 22 }),
            new TextRun({ text: dates.trim() !== '–' ? `   (${dates})` : '', size: 20, color: '6b7280', italics: true })
          ]
        })
      );
    }
  }

  if ((resume.projects || []).length) {
    children.push(heading('Projects', accentHex));
    for (const proj of resume.projects) {
      children.push(
        new Paragraph({
          spacing: { before: 80 },
          children: [new TextRun({ text: proj.name || '', bold: true, size: 22 })]
        })
      );
      if (proj.description) {
        children.push(new Paragraph({ children: [new TextRun({ text: proj.description, size: 21 })] }));
      }
      children.push(...bulletParagraphs(proj.bullets));
    }
  }

  if ((resume.skills || []).length) {
    children.push(heading('Skills', accentHex));
    children.push(new Paragraph({ children: [new TextRun({ text: resume.skills.filter(Boolean).join('  •  '), size: 21 })] }));
  }

  if ((resume.certifications || []).length) {
    children.push(heading('Certifications', accentHex));
    for (const c of resume.certifications) {
      children.push(
        new Paragraph({
          children: [
            new TextRun({ text: c.name || '', bold: true, size: 21 }),
            new TextRun({ text: c.issuer ? `  —  ${c.issuer}` : '', size: 21 }),
            new TextRun({ text: c.date ? `   (${c.date})` : '', size: 20, color: '6b7280' })
          ]
        })
      );
    }
  }

  if ((resume.languages || []).filter((l) => l && l.name).length) {
    children.push(heading('Languages', accentHex));
    children.push(
      new Paragraph({
        children: [
          new TextRun({
            text: resume.languages
              .filter((l) => l && l.name)
              .map((l) => `${l.name}${l.level ? ` (${l.level})` : ''}`)
              .join('  •  '),
            size: 21
          })
        ]
      })
    );
  }

  const doc = new Document({
    sections: [{ properties: {}, children }]
  });

  return Packer.toBuffer(doc);
}
