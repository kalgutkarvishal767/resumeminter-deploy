import mongoose from 'mongoose';

const experienceSchema = new mongoose.Schema(
  {
    company: String,
    role: String,
    location: String,
    startDate: String,
    endDate: String,
    current: { type: Boolean, default: false },
    bullets: [String]
  },
  { _id: false }
);

const educationSchema = new mongoose.Schema(
  {
    school: String,
    degree: String,
    field: String,
    location: String,
    startDate: String,
    endDate: String,
    grade: String
  },
  { _id: false }
);

const projectSchema = new mongoose.Schema(
  {
    name: String,
    link: String,
    description: String,
    bullets: [String]
  },
  { _id: false }
);

const certificationSchema = new mongoose.Schema(
  {
    name: String,
    issuer: String,
    date: String
  },
  { _id: false }
);

const resumeSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    title: { type: String, default: 'Untitled Resume' },
    templateId: { type: String, default: 'classic-01' },
    accentColor: { type: String, default: '#2563eb' },
    fontFamily: { type: String, default: 'inter' },

    personalInfo: {
      fullName: { type: String, default: '' },
      jobTitle: { type: String, default: '' },
      email: { type: String, default: '' },
      phone: { type: String, default: '' },
      location: { type: String, default: '' },
      website: { type: String, default: '' },
      linkedin: { type: String, default: '' },
      photoUrl: { type: String, default: '' }
    },

    summary: { type: String, default: '' },
    experience: [experienceSchema],
    education: [educationSchema],
    skills: [{ type: String }],
    languages: [{ name: String, level: String }],
    projects: [projectSchema],
    certifications: [certificationSchema],

    // Order/visibility of sections lets the user rearrange or hide sections per template.
    sectionOrder: {
      type: [String],
      default: ['summary', 'experience', 'education', 'skills', 'projects', 'certifications', 'languages']
    },

    // Per-section typography overrides, e.g. { experience: { fontFamily: 'lora', fontSize: 13 } }.
    // Keyed by the same section ids used in sectionOrder. Validated/sanitized
    // again in shared/resumeHtmlRenderer.js before being turned into CSS.
    sectionStyles: { type: mongoose.Schema.Types.Mixed, default: {} }
  },
  { timestamps: true }
);

export default mongoose.model('Resume', resumeSchema);
