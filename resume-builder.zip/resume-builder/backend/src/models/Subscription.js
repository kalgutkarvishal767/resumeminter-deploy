import mongoose from 'mongoose';

// Full history/audit log of subscription events, separate from the denormalized
// snapshot stored on User. Useful for support, invoicing, and debugging webhooks.
const subscriptionSchema = new mongoose.Schema(
  {
    user: { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true, index: true },
    razorpaySubscriptionId: { type: String, required: true, unique: true },
    razorpayCustomerId: { type: String },
    plan: { type: String, enum: ['monthly', 'quarterly'], required: true },
    status: {
      type: String,
      enum: ['created', 'authenticated', 'active', 'past_due', 'halted', 'cancelled', 'completed', 'expired'],
      default: 'created'
    },
    currentStart: Date,
    currentEnd: Date,
    lastPaymentId: String,
    rawEvents: [{ event: String, payload: mongoose.Schema.Types.Mixed, receivedAt: Date }]
  },
  { timestamps: true }
);

export default mongoose.model('Subscription', subscriptionSchema);
