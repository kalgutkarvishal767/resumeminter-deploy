import mongoose from 'mongoose';
import bcrypt from 'bcryptjs';

const userSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    email: { type: String, required: true, unique: true, lowercase: true, trim: true },
    passwordHash: { type: String, required: true },

    // Denormalized subscription snapshot for fast gating checks.
    // Source of truth is the Subscription collection; this is kept in sync via webhooks.
    subscription: {
      status: {
        type: String,
        enum: ['none', 'active', 'past_due', 'cancelled', 'expired'],
        default: 'none'
      },
      plan: { type: String, enum: [null, 'monthly', 'quarterly'], default: null },
      currentPeriodEnd: { type: Date, default: null },
      razorpaySubscriptionId: { type: String, default: null },
      razorpayCustomerId: { type: String, default: null }
    },

    // Password reset flow. We store only a hash of the reset token (never the
    // raw token, which is only ever emailed to the user) so a database leak
    // alone can't be used to reset anyone's password.
    resetPasswordTokenHash: { type: String, default: null, select: false },
    resetPasswordExpires: { type: Date, default: null, select: false }
  },
  { timestamps: true }
);

userSchema.methods.setPassword = async function setPassword(plainPassword) {
  const salt = await bcrypt.genSalt(10);
  this.passwordHash = await bcrypt.hash(plainPassword, salt);
};

userSchema.methods.comparePassword = function comparePassword(plainPassword) {
  return bcrypt.compare(plainPassword, this.passwordHash);
};

userSchema.methods.hasActiveSubscription = function hasActiveSubscription() {
  if (this.subscription.status !== 'active') return false;
  if (!this.subscription.currentPeriodEnd) return false;
  return new Date(this.subscription.currentPeriodEnd) > new Date();
};

userSchema.methods.toSafeJSON = function toSafeJSON() {
  return {
    id: this._id,
    name: this.name,
    email: this.email,
    subscription: this.subscription,
    createdAt: this.createdAt
  };
};

export default mongoose.model('User', userSchema);
