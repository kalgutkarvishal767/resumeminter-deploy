import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // The live resume preview imports the shared renderer from ../shared,
    // which lives outside this project's root — allow Vite's dev server to
    // serve files from the parent (monorepo) directory.
    fs: { allow: ['..'] },
    // During local dev, proxy /api calls to the backend so the frontend can
    // just call api.get('/resumes') etc. without CORS/base-URL juggling.
    proxy: {
      '/api': {
        target: 'http://localhost:5000',
        changeOrigin: true
      }
    }
  }
});
