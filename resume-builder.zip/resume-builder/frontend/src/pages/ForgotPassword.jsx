import { useState } from 'react';
import { Link } from 'react-router-dom';
import { api } from '../api/client.js';
import AuthLayout from '../components/AuthLayout.jsx';

export default function ForgotPassword() {
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  async function onSubmit(e) {
    e.preventDefault();
    setError('');
    setMessage('');
    setBusy(true);
    try {
      const { data } = await api.post('/auth/forgot-password', { email });
      setMessage(data.message);
    } catch (err) {
      setError(err.response?.data?.error || 'Something went wrong. Please try again.');
    } finally {
      setBusy(false);
    }
  }

  return (
    <AuthLayout eyebrow="Reset your password" title="Forgot your password?">
      {message ? (
        <div className="text-center">
          <p className="text-sm text-gray-700">{message}</p>
          <Link to="/login" className="text-brand-600 font-semibold text-sm mt-4 inline-block">
            Back to log in
          </Link>
        </div>
      ) : (
        <>
          <p className="text-sm text-gray-500 mb-4">
            Enter the email address on your account and we'll send you a link to reset your password.
          </p>
          <form onSubmit={onSubmit} className="space-y-4">
            <div>
              <label className="label">Email</label>
              <input
                className="input"
                type="email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
              />
            </div>
            {error && <p className="text-sm text-red-600">{error}</p>}
            <button className="btn-primary w-full" disabled={busy}>
              {busy ? 'Sending…' : 'Send reset link'}
            </button>
          </form>
          <p className="text-sm text-gray-500 mt-5 text-center">
            Remembered it?{' '}
            <Link to="/login" className="text-brand-600 font-semibold">
              Log in
            </Link>
          </p>
        </>
      )}
    </AuthLayout>
  );
}
