import { Link } from 'react-router-dom';

export default function BillingSuccess() {
  return (
    <div className="max-w-md mx-auto mt-20 text-center card p-8">
      <div className="text-4xl mb-4">🎉</div>
      <h1 className="text-xl font-bold mb-2">You're subscribed!</h1>
      <p className="text-gray-600 mb-6">
        Your payment was successful. You now have unlimited resumes and downloads.
      </p>
      <Link to="/dashboard" className="btn-primary">
        Go to my resumes
      </Link>
    </div>
  );
}
