import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import ResumeForm from '../components/ResumeForm/index.jsx';
import ResumePreview from '../components/ResumePreview.jsx';
import { TEMPLATES, getTemplateById } from '../../../shared/templateRegistry.js';

const SAVE_DEBOUNCE_MS = 900;

export default function ResumeEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { isSubscribed } = useAuth();

  const [resume, setResume] = useState(null);
  const [saving, setSaving] = useState(false);
  const [exportError, setExportError] = useState('');
  const [exporting, setExporting] = useState(null);
  const [showTemplatePicker, setShowTemplatePicker] = useState(false);
  const saveTimer = useRef(null);

  useEffect(() => {
    api.get(`/resumes/${id}`).then(({ data }) => setResume(data.resume));
  }, [id]);

  function scheduleSave(next) {
    setResume(next);
    setSaving(true);
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      try {
        await api.put(`/resumes/${id}`, next);
      } finally {
        setSaving(false);
      }
    }, SAVE_DEBOUNCE_MS);
  }

  function onUpdate(patch) {
    scheduleSave({ ...resume, ...patch });
  }

  function changeTemplate(templateId) {
    const template = getTemplateById(templateId);
    scheduleSave({ ...resume, templateId, accentColor: template.defaultAccentColor });
    setShowTemplatePicker(false);
  }

  async function handleExport(format) {
    setExportError('');
    setExporting(format);
    try {
      const response = await api.get(`/export/${id}/${format}`, { responseType: 'blob' });
      const blob = new Blob([response.data]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${resume.title || 'resume'}.${format === 'pdf' ? 'pdf' : 'docx'}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);
    } catch (err) {
      if (err.response?.status === 402) {
        navigate('/pricing');
      } else {
        setExportError('Failed to export. Please try again.');
      }
    } finally {
      setExporting(null);
    }
  }

  if (!resume) return <div className="p-10 text-center text-gray-500">Loading resume…</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-4 gap-3">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <Link to="/dashboard" className="text-sm text-gray-500 hover:text-gray-800 shrink-0">
            ← Back
          </Link>
          <input
            className="text-lg font-semibold bg-transparent border-b border-transparent hover:border-gray-300 focus:border-brand-500 focus:outline-none flex-1 min-w-0"
            value={resume.title}
            onChange={(e) => onUpdate({ title: e.target.value })}
          />
        </div>
        <span className="text-xs text-gray-400 shrink-0">{saving ? 'Saving…' : 'Saved'}</span>
        <div className="flex gap-2 shrink-0">
          <button className="btn-secondary !py-1.5" onClick={() => setShowTemplatePicker((v) => !v)}>
            Change template
          </button>
          <input
            type="color"
            className="w-9 h-9 rounded-lg border border-gray-300 cursor-pointer"
            value={resume.accentColor}
            onChange={(e) => onUpdate({ accentColor: e.target.value })}
            title="Accent color"
          />
          <button className="btn-secondary !py-1.5" disabled={exporting === 'pdf'} onClick={() => handleExport('pdf')}>
            {exporting === 'pdf' ? 'Preparing…' : 'Download PDF'}
          </button>
          <button className="btn-primary !py-1.5" disabled={exporting === 'docx'} onClick={() => handleExport('docx')}>
            {exporting === 'docx' ? 'Preparing…' : 'Download Word'}
          </button>
        </div>
      </div>

      {!isSubscribed && (
        <div className="card p-3 mb-4 bg-amber-50 border-amber-200 text-sm text-amber-800">
          Downloads require an active subscription. <Link to="/pricing" className="font-semibold underline">Upgrade now</Link>.
        </div>
      )}
      {exportError && <p className="text-sm text-red-600 mb-4">{exportError}</p>}

      {showTemplatePicker && (
        <div className="card p-4 mb-4 grid grid-cols-4 sm:grid-cols-8 gap-2">
          {TEMPLATES.map((t) => (
            <button
              key={t.id}
              onClick={() => changeTemplate(t.id)}
              className={`h-14 rounded-md text-[10px] text-white font-semibold flex items-center justify-center px-1 text-center ${
                t.id === resume.templateId ? 'ring-2 ring-offset-2 ring-brand-500' : ''
              }`}
              style={{ background: t.defaultAccentColor }}
              title={t.name}
            >
              {t.name}
            </button>
          ))}
        </div>
      )}

      <div className="grid lg:grid-cols-[420px_1fr] gap-6">
        <div>
          <ResumeForm resume={resume} onUpdate={onUpdate} />
        </div>
        <div className="lg:sticky lg:top-6 self-start">
          <ResumePreview resume={resume} />
        </div>
      </div>
    </div>
  );
}
