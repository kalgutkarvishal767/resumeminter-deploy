import { useEffect, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

export default function Dashboard() {
  const [resumes, setResumes] = useState([]);
  const [loading, setLoading] = useState(true);
  const { isSubscribed } = useAuth();
  const navigate = useNavigate();

  async function load() {
    setLoading(true);
    const { data } = await api.get('/resumes');
    setResumes(data.resumes);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function handleDelete(id) {
    if (!confirm('Delete this resume? This cannot be undone.')) return;
    await api.delete(`/resumes/${id}`);
    load();
  }

  async function handleDuplicate(id) {
    try {
      await api.post(`/resumes/${id}/duplicate`);
      load();
    } catch (err) {
      if (err.response?.data?.code === 'SUBSCRIPTION_REQUIRED') {
        navigate('/pricing');
      }
    }
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-2xl font-bold">My Resumes</h1>
        <Link to="/templates" className="btn-primary">
          + New Resume
        </Link>
      </div>

      {!isSubscribed && (
        <div className="card p-4 mb-6 bg-amber-50 border-amber-200 flex items-center justify-between">
          <p className="text-sm text-amber-800">
            You're on the free plan (1 resume, no downloads). Subscribe to unlock unlimited resumes and PDF/Word
            downloads.
          </p>
          <Link to="/pricing" className="btn-primary !py-1.5 shrink-0 ml-4">
            Upgrade
          </Link>
        </div>
      )}

      {loading ? (
        <p className="text-gray-500">Loading…</p>
      ) : resumes.length === 0 ? (
        <div className="card p-10 text-center text-gray-500">
          You don't have any resumes yet. <Link to="/templates" className="text-brand-600 font-semibold">Create one</Link>.
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {resumes.map((r) => (
            <div key={r._id} className="card p-4 flex flex-col justify-between">
              <div>
                <h3 className="font-semibold">{r.title}</h3>
                <p className="text-xs text-gray-500 mt-1">Template: {r.templateId}</p>
                <p className="text-xs text-gray-400">Updated {new Date(r.updatedAt).toLocaleDateString()}</p>
              </div>
              <div className="flex gap-2 mt-4">
                <Link to={`/resumes/${r._id}`} className="btn-primary !py-1.5 flex-1 text-center">
                  Edit
                </Link>
                <button onClick={() => handleDuplicate(r._id)} className="btn-secondary !py-1.5">
                  Duplicate
                </button>
                <button onClick={() => handleDelete(r._id)} className="btn-secondary !py-1.5 text-red-600">
                  Delete
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
