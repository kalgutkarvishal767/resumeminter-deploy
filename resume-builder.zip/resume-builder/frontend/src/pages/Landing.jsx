import { Link } from 'react-router-dom';
import { TEMPLATES } from '../../../shared/templateRegistry.js';

export default function Landing() {
  return (
    <div>
      <section className="max-w-5xl mx-auto px-4 pt-20 pb-16 text-center">
        <h1 className="text-4xl sm:text-5xl font-extrabold tracking-tight text-gray-900">
          Build a resume that gets you hired.
        </h1>
        <p className="mt-4 text-lg text-gray-600 max-w-2xl mx-auto">
          Choose from {TEMPLATES.length}+ professionally designed templates, fill in your details, and download a
          polished PDF or Word resume in minutes.
        </p>
        <div className="mt-8 flex items-center justify-center gap-3">
          <Link to="/register" className="btn-primary text-base px-6 py-3">
            Create your resume — free
          </Link>
          <Link to="/pricing" className="btn-secondary text-base px-6 py-3">
            See pricing
          </Link>
        </div>
      </section>

      <section className="max-w-6xl mx-auto px-4 pb-20">
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
          {TEMPLATES.slice(0, 8).map((t) => (
            <div key={t.id} className="card p-3">
              <div
                className="h-28 rounded-md mb-2"
                style={{ background: `linear-gradient(135deg, ${t.defaultAccentColor}22, ${t.defaultAccentColor}55)` }}
              />
              <div className="text-sm font-semibold">{t.name}</div>
              <div className="text-xs text-gray-500">{t.category}</div>
            </div>
          ))}
        </div>
        <p className="text-center text-sm text-gray-500 mt-6">
          …and {TEMPLATES.length - 8} more templates, from minimalist &amp; ATS-friendly to bold &amp; creative.
        </p>
      </section>

      <section className="bg-white border-t border-gray-200">
        <div className="max-w-5xl mx-auto px-4 py-16 grid sm:grid-cols-3 gap-8 text-center">
          <div>
            <div className="text-2xl mb-2">🎨</div>
            <h3 className="font-semibold mb-1">{TEMPLATES.length}+ templates</h3>
            <p className="text-sm text-gray-600">From classic and ATS-safe to bold and creative — switch anytime.</p>
          </div>
          <div>
            <div className="text-2xl mb-2">⬇️</div>
            <h3 className="font-semibold mb-1">PDF &amp; Word export</h3>
            <p className="text-sm text-gray-600">Download a pixel-perfect PDF or an ATS-friendly Word document.</p>
          </div>
          <div>
            <div className="text-2xl mb-2">💳</div>
            <h3 className="font-semibold mb-1">Simple subscription</h3>
            <p className="text-sm text-gray-600">One low monthly or quarterly price. Cancel anytime.</p>
          </div>
        </div>
      </section>
    </div>
  );
}
