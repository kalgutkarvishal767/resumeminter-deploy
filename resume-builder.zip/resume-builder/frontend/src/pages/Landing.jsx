import { Link } from 'react-router-dom';
import { TEMPLATES } from '../../../shared/templateRegistry.js';
import ColorBlobs from '../components/ColorBlobs.jsx';

const FEATURES = [
  {
    icon: '🎨',
    title: `${TEMPLATES.length}+ templates`,
    body: 'From classic and ATS-safe to bold and creative — switch anytime, no extra charge.'
  },
  {
    icon: '⬇️',
    title: 'PDF & Word export',
    body: 'Download a pixel-perfect PDF, or a clean ATS-friendly Word document for editing.'
  },
  {
    icon: '🤖',
    title: 'ATS-optimized',
    body: 'Every layout is built to pass applicant tracking systems, not just look good.'
  },
  {
    icon: '💳',
    title: 'One simple price',
    body: 'A single low monthly or quarterly plan. No hidden add-ons. Cancel anytime.'
  }
];

// Duplicate the template list so the CSS marquee can loop seamlessly.
const marqueeTemplates = [...TEMPLATES, ...TEMPLATES];

export default function Landing() {
  return (
    <div className="overflow-x-hidden">
      {/* Hero */}
      <section className="relative isolate">
        <ColorBlobs variant="hero" />
        <div className="relative z-10 max-w-5xl mx-auto px-4 pt-24 pb-20 text-center">
          <span className="inline-block text-xs font-semibold tracking-wide uppercase bg-white/70 backdrop-blur px-3 py-1 rounded-full text-brand-600 border border-brand-100 mb-6">
            Free to start · No design skills needed
          </span>
          <h1 className="text-4xl sm:text-6xl font-extrabold tracking-tight text-gray-900">
            Build a resume that <span className="text-gradient">gets you hired.</span>
          </h1>
          <p className="mt-5 text-lg text-gray-600 max-w-2xl mx-auto">
            Choose from {TEMPLATES.length}+ professionally designed templates, fill in your details, and download a
            polished PDF or Word resume in minutes.
          </p>
          <div className="mt-9 flex flex-wrap items-center justify-center gap-3">
            <Link to="/register" className="btn-primary text-base px-7 py-3">
              Create your resume — free
            </Link>
            <Link to="/pricing" className="btn-secondary text-base px-7 py-3">
              See pricing
            </Link>
          </div>
        </div>
      </section>

      {/* Auto-scrolling template showcase */}
      <section className="pb-20">
        <p className="text-center text-sm font-semibold text-gray-500 mb-6">
          A template for every industry and career stage
        </p>
        <div className="marquee-viewport relative overflow-hidden [mask-image:linear-gradient(to_right,transparent,black_10%,black_90%,transparent)]">
          <div className="marquee-track">
            {marqueeTemplates.map((t, i) => (
              <div
                key={`${t.id}-${i}`}
                className="w-44 shrink-0 rounded-xl border border-gray-200 bg-white shadow-sm p-3"
              >
                <div
                  className="h-28 rounded-lg mb-2"
                  style={{ background: `linear-gradient(150deg, ${t.defaultAccentColor}, ${t.defaultAccentColor}99)` }}
                />
                <div className="text-xs font-semibold truncate">{t.name}</div>
                <div className="text-[10px] text-gray-400">{t.category}</div>
              </div>
            ))}
          </div>
        </div>
        <p className="text-center text-sm text-gray-500 mt-6">
          …and plenty more, from minimalist &amp; ATS-friendly to bold &amp; creative.
        </p>
      </section>

      {/* Features */}
      <section className="bg-white border-t border-gray-200">
        <div className="max-w-6xl mx-auto px-4 py-20">
          <h2 className="text-2xl sm:text-3xl font-bold text-center mb-2">Everything you need, nothing you don't</h2>
          <p className="text-gray-600 text-center mb-12 max-w-xl mx-auto">
            A focused resume builder — no clutter, no confusing upsells.
          </p>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {FEATURES.map((f) => (
              <div key={f.title} className="card p-6 text-center hover:shadow-md transition-shadow">
                <div className="text-3xl mb-3">{f.icon}</div>
                <h3 className="font-semibold mb-1">{f.title}</h3>
                <p className="text-sm text-gray-600">{f.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Final CTA banner */}
      <section className="relative isolate overflow-hidden">
        <div
          className="absolute inset-0"
          style={{ background: 'linear-gradient(120deg, #7c3aed 0%, #ec4899 55%, #fb923c 100%)' }}
        />
        <div className="relative z-10 max-w-3xl mx-auto px-4 py-16 text-center text-white">
          <h2 className="text-2xl sm:text-3xl font-bold mb-3">Ready to build yours?</h2>
          <p className="text-white/90 mb-8">It takes less time than reading one more job posting.</p>
          <Link
            to="/register"
            className="inline-flex items-center justify-center rounded-full bg-white text-brand-600 font-semibold px-7 py-3 hover:-translate-y-0.5 transition-transform shadow-lg"
          >
            Get started — it's free
          </Link>
        </div>
      </section>
    </div>
  );
}
