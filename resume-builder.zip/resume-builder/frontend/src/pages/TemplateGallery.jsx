import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TEMPLATES } from '../../../shared/templateRegistry.js';
import { api } from '../api/client.js';

const CATEGORIES = ['All', ...new Set(TEMPLATES.map((t) => t.category))];

export default function TemplateGallery() {
  const [category, setCategory] = useState('All');
  const [creatingId, setCreatingId] = useState(null);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const visible = category === 'All' ? TEMPLATES : TEMPLATES.filter((t) => t.category === category);

  async function chooseTemplate(templateId) {
    setError('');
    setCreatingId(templateId);
    try {
      const { data } = await api.post('/resumes', { title: 'Untitled Resume', templateId });
      navigate(`/resumes/${data.resume._id}`);
    } catch (err) {
      if (err.response?.data?.code === 'SUBSCRIPTION_REQUIRED') {
        navigate('/pricing');
      } else {
        setError(err.response?.data?.error || 'Failed to create resume');
      }
    } finally {
      setCreatingId(null);
    }
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <h1 className="text-2xl font-bold mb-2">Choose a template</h1>
      <p className="text-gray-600 mb-6">{TEMPLATES.length} templates available. You can switch templates anytime later.</p>

      <div className="flex flex-wrap gap-2 mb-6">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`px-3 py-1.5 rounded-full text-sm font-medium border ${
              category === c ? 'bg-brand-500 text-white border-brand-500' : 'bg-white text-gray-600 border-gray-300'
            }`}
          >
            {c}
          </button>
        ))}
      </div>

      {error && <p className="text-sm text-red-600 mb-4">{error}</p>}

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {visible.map((t) => (
          <button
            key={t.id}
            onClick={() => chooseTemplate(t.id)}
            disabled={creatingId === t.id}
            className="card p-3 text-left hover:shadow-md transition-shadow disabled:opacity-60"
          >
            <div
              className="h-36 rounded-md mb-3 flex items-center justify-center text-white text-xs font-semibold"
              style={{ background: `linear-gradient(160deg, ${t.defaultAccentColor}, ${t.defaultAccentColor}99)` }}
            >
              {t.layout}
            </div>
            <div className="text-sm font-semibold">{t.name}</div>
            <div className="text-xs text-gray-500 mb-1">{t.category}</div>
            <p className="text-xs text-gray-500">{t.description}</p>
            {t.atsFriendly && (
              <span className="inline-block mt-2 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                ATS-friendly
              </span>
            )}
            {creatingId === t.id && <p className="text-xs text-brand-600 mt-2">Creating…</p>}
          </button>
        ))}
      </div>
    </div>
  );
}
