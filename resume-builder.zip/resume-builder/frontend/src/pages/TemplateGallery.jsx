import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { TEMPLATES } from '../../../shared/templateRegistry.js';
import { api } from '../api/client.js';

const CATEGORIES = ['All', ...new Set(TEMPLATES.map((t) => t.category))];

export default function TemplateGallery() {
  const [category, setCategory] = useState('All');
  const [creatingId, setCreatingId] = useState(null);
  const [error, setError] = useState('');
  const navigate = useNavigate();

  const visible = category === 'All' ? TEMPLATES : TEMPLATES.filter((t) => t.category === category);

  async function chooseTemplate(templateId) {
    setError('');
    setCreatingId(templateId);
    try {
      const { data } = await api.post('/resumes', { title: 'Untitled Resume', templateId });
      navigate(`/resumes/${data.resume._id}`);
    } catch (err) {
      if (err.response?.data?.code === 'SUBSCRIPTION_REQUIRED') {
        navigate('/pricing');
      } else {
        setError(err.response?.data?.error || 'Failed to create resume');
      }
    } finally {
      setCreatingId(null);
    }
  }

  return (
    <div className="max-w-6xl mx-auto px-4 py-10">
      <div className="text-center mb-8">
        <h1 className="text-3xl font-bold mb-2">
          Choose a <span className="text-gradient">template</span>
        </h1>
        <p className="text-gray-600">{TEMPLATES.length} templates available. You can switch templates anytime later.</p>
      </div>

      <div className="flex flex-wrap justify-center gap-2 mb-8">
        {CATEGORIES.map((c) => (
          <button
            key={c}
            onClick={() => setCategory(c)}
            className={`px-4 py-1.5 rounded-full text-sm font-medium border transition-colors ${
              category === c
                ? 'text-white border-transparent shadow-md'
                : 'bg-white text-gray-600 border-gray-300 hover:border-brand-300'
            }`}
            style={category === c ? { backgroundImage: 'linear-gradient(135deg, #7c3aed, #ec4899)' } : undefined}
          >
            {c}
          </button>
        ))}
      </div>

      {error && <p className="text-sm text-red-600 mb-4 text-center">{error}</p>}

      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-5">
        {visible.map((t) => (
          <button
            key={t.id}
            onClick={() => chooseTemplate(t.id)}
            disabled={creatingId === t.id}
            className="card p-3 text-left hover:shadow-lg hover:-translate-y-1 transition-all disabled:opacity-60"
          >
            <div
              className="h-40 rounded-md mb-3 flex items-end p-3 text-white text-xs font-semibold relative overflow-hidden"
              style={{ background: `linear-gradient(160deg, ${t.defaultAccentColor}, ${t.defaultAccentColor}99)` }}
            >
              <div className="absolute inset-3 top-3 bottom-auto space-y-1.5 opacity-80">
                <div className="h-1.5 w-2/3 rounded bg-white/70" />
                <div className="h-1.5 w-1/2 rounded bg-white/50" />
                <div className="h-1.5 w-3/5 rounded bg-white/50" />
              </div>
              <span className="relative z-10">{t.layout}</span>
            </div>
            <div className="text-sm font-semibold">{t.name}</div>
            <div className="text-xs text-gray-500 mb-1">{t.category}</div>
            <p className="text-xs text-gray-500">{t.description}</p>
            {t.atsFriendly && (
              <span className="inline-block mt-2 text-[10px] font-semibold text-emerald-700 bg-emerald-50 px-2 py-0.5 rounded-full">
                ATS-friendly
              </span>
            )}
            {creatingId === t.id && <p className="text-xs text-brand-600 mt-2">Creating…</p>}
          </button>
        ))}
      </div>
    </div>
  );
}
