import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';

const PLAN_DETAILS = {
  monthly: { price: '₹199', period: '/ month', blurb: 'Billed every month. Cancel anytime.' },
  quarterly: { price: '₹499', period: '/ quarter', blurb: 'Save vs. monthly. Billed every 3 months.', badge: 'Best value' }
};
// NOTE: these prices are placeholders for the UI. The real amount charged is
// whatever you configure on the Plan in the Razorpay Dashboard — update
// these display strings to match once you create your live plans.

function loadRazorpayScript() {
  return new Promise((resolve) => {
    if (window.Razorpay) return resolve(true);
    const script = document.createElement('script');
    script.src = 'https://checkout.razorpay.com/v1/checkout.js';
    script.onload = () => resolve(true);
    script.onerror = () => resolve(false);
    document.body.appendChild(script);
  });
}

export default function Pricing() {
  const { user, isSubscribed, refreshUser } = useAuth();
  const navigate = useNavigate();
  const [plans, setPlans] = useState([]);
  const [busyPlan, setBusyPlan] = useState(null);
  const [error, setError] = useState('');

  useEffect(() => {
    api.get('/subscriptions/plans').then(({ data }) => setPlans(data.plans));
  }, []);

  async function subscribe(planId) {
    if (!user) {
      navigate('/register');
      return;
    }
    setError('');
    setBusyPlan(planId);
    try {
      const scriptOk = await loadRazorpayScript();
      if (!scriptOk) throw new Error('Could not load Razorpay checkout');

      const { data } = await api.post('/subscriptions/create', { plan: planId });

      const rzp = new window.Razorpay({
        key: data.razorpayKeyId,
        subscription_id: data.subscriptionId,
        name: 'Resume Minter',
        description: `${PLAN_DETAILS[planId].price} ${PLAN_DETAILS[planId].period}`,
        theme: { color: '#4f46e5' },
        prefill: { name: user.name, email: user.email },
        handler: async (response) => {
          try {
            await api.post('/subscriptions/confirm', response);
            await refreshUser();
            navigate('/billing/success');
          } catch (err) {
            setError('Payment succeeded but confirmation failed. Please contact support.');
          }
        },
        modal: { ondismiss: () => setBusyPlan(null) }
      });
      rzp.open();
    } catch (err) {
      setError(err.response?.data?.error || err.message || 'Failed to start checkout');
      setBusyPlan(null);
    }
  }

  async function cancel() {
    if (!confirm('Cancel your subscription at the end of the current billing period?')) return;
    await api.post('/subscriptions/cancel');
    await refreshUser();
  }

  return (
    <div className="max-w-4xl mx-auto px-4 py-14">
      <h1 className="text-3xl font-bold text-center mb-2">
        Simple, <span className="text-gradient">nominal pricing</span>
      </h1>
      <p className="text-gray-600 text-center mb-10">Unlimited resumes, every template, unlimited PDF/Word downloads.</p>

      {error && <p className="text-sm text-red-600 text-center mb-6">{error}</p>}

      <div className="grid sm:grid-cols-2 gap-6">
        {(plans.length ? plans : [{ id: 'monthly' }, { id: 'quarterly' }]).map((p) => {
          const details = PLAN_DETAILS[p.id];
          const isCurrentPlan = isSubscribed && user?.subscription?.plan === p.id;
          return (
            <div key={p.id} className="card p-6 relative">
              {details.badge && (
                <span
                  className="absolute -top-3 right-4 text-xs font-semibold text-white px-2 py-1 rounded-full shadow"
                  style={{ backgroundImage: 'linear-gradient(135deg, #7c3aed, #ec4899)' }}
                >
                  {details.badge}
                </span>
              )}
              <h2 className="text-lg font-semibold capitalize">{p.id}</h2>
              <div className="mt-2 mb-1">
                <span className="text-3xl font-extrabold">{details.price}</span>
                <span className="text-gray-500"> {details.period}</span>
              </div>
              <p className="text-sm text-gray-500 mb-4">{details.blurb}</p>
              {isCurrentPlan ? (
                <button className="btn-secondary w-full" onClick={cancel}>
                  Cancel subscription
                </button>
              ) : (
                <button className="btn-primary w-full" disabled={busyPlan === p.id} onClick={() => subscribe(p.id)}>
                  {busyPlan === p.id ? 'Opening checkout…' : 'Subscribe'}
                </button>
              )}
            </div>
          );
        })}
      </div>

      <p className="text-xs text-gray-400 text-center mt-8">
        Payments are securely processed by Razorpay. You can cancel anytime from this page.
      </p>
    </div>
  );
}
