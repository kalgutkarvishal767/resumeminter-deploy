import axios from 'axios';

// In production, set VITE_API_URL at build time to your backend's public URL
// (e.g. https://api.yourdomain.com/api). Falls back to same-origin /api for
// local development behind Vite's proxy, or if you serve both from one host.
const baseURL = import.meta.env.VITE_API_URL || '/api';

export const api = axios.create({ baseURL });

api.interceptors.request.use((config) => {
  const token = localStorage.getItem('rb_token');
  if (token) {
    config.headers.Authorization = `Bearer ${token}`;
  }
  return config;
});

api.interceptors.response.use(
  (res) => res,
  (err) => {
    if (err.response && err.response.status === 401) {
      localStorage.removeItem('rb_token');
    }
    return Promise.reject(err);
  }
);
