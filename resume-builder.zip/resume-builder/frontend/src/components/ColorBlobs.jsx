// Decorative, purely visual blurred-color-blob background. Renders behind
// content (parent must be `relative`) and never captures clicks.
export default function ColorBlobs({ variant = 'hero' }) {
  const palettes = {
    hero: ['#a78bfa', '#f472b6', '#fb923c'],
    auth: ['#f472b6', '#7c3aed', '#2dd4bf']
  };
  const colors = palettes[variant] || palettes.hero;

  return (
    <div className="blob-bg pointer-events-none" aria-hidden="true">
      <span
        className="w-72 h-72 sm:w-96 sm:h-96 -top-10 -left-10 animate-blob"
        style={{ background: colors[0] }}
      />
      <span
        className="w-72 h-72 sm:w-96 sm:h-96 top-10 right-0 animate-blob"
        style={{ background: colors[1], animationDelay: '2s' }}
      />
      <span
        className="w-72 h-72 sm:w-96 sm:h-96 bottom-0 left-1/3 animate-blob"
        style={{ background: colors[2], animationDelay: '4s' }}
      />
    </div>
  );
}
