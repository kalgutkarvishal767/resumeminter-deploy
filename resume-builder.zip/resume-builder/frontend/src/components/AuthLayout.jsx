import { Link } from 'react-router-dom';
import ColorBlobs from './ColorBlobs.jsx';

export default function AuthLayout({ eyebrow, title, children }) {
  return (
    <div className="relative isolate min-h-[calc(100vh-4rem)] flex items-center justify-center overflow-hidden px-4 py-14">
      <ColorBlobs variant="auth" />
      <div className="relative z-10 w-full max-w-md">
        <div className="text-center mb-6">
          <Link to="/" className="text-2xl font-extrabold text-gradient">
            Resume Minter
          </Link>
          <p className="text-xs uppercase tracking-wide text-gray-500 font-semibold mt-2">{eyebrow}</p>
          <h1 className="text-xl font-bold mt-1">{title}</h1>
        </div>
        <div className="card p-6 backdrop-blur bg-white/90">{children}</div>
      </div>
    </div>
  );
}
