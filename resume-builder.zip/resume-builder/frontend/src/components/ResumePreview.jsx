import { useEffect, useMemo, useRef, useState } from 'react';
import { renderResumeHTML } from '../../../shared/resumeHtmlRenderer.js';
import { getTemplateById } from '../../../shared/templateRegistry.js';

const PAGE_WIDTH = 794; // matches the A4-at-96dpi width baked into resumeHtmlRenderer.js

// Renders the resume using the exact same HTML/CSS the backend feeds to
// Puppeteer for PDF export, inside a sandboxed <iframe>. This guarantees the
// live preview is pixel-accurate to the downloaded PDF, and keeps the
// template's CSS from ever leaking into (or being polluted by) the app UI.
export default function ResumePreview({ resume }) {
  const containerRef = useRef(null);
  const [scale, setScale] = useState(1);

  const template = getTemplateById(resume.templateId);
  const html = useMemo(() => (template ? renderResumeHTML(resume, template) : '<p>Unknown template</p>'), [resume, template]);

  useEffect(() => {
    function updateScale() {
      if (containerRef.current) {
        const width = containerRef.current.offsetWidth;
        setScale(Math.min(1, width / PAGE_WIDTH));
      }
    }
    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, []);

  return (
    <div ref={containerRef} className="w-full overflow-hidden">
      <div style={{ height: 1123 * scale }}>
        <iframe
          title="Resume preview"
          srcDoc={html}
          style={{
            width: PAGE_WIDTH,
            height: 1123,
            border: 'none',
            transform: `scale(${scale})`,
            transformOrigin: 'top left',
            boxShadow: '0 1px 3px rgba(0,0,0,0.15)',
            background: '#fff'
          }}
        />
      </div>
    </div>
  );
}
