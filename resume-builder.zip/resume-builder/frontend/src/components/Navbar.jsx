import { Link, useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext.jsx';

export default function Navbar() {
  const { user, logout, isSubscribed } = useAuth();
  const navigate = useNavigate();

  return (
    <nav className="border-b border-gray-200 bg-white">
      <div className="max-w-7xl mx-auto px-4 h-16 flex items-center justify-between">
        <Link to="/" className="font-extrabold text-xl text-brand-600">
          ResumeForge
        </Link>
        <div className="flex items-center gap-4 text-sm">
          {user ? (
            <>
              <Link to="/dashboard" className="text-gray-600 hover:text-gray-900">
                My Resumes
              </Link>
              <Link to="/pricing" className="text-gray-600 hover:text-gray-900">
                {isSubscribed ? 'Manage Plan' : 'Upgrade'}
              </Link>
              {isSubscribed && (
                <span className="text-xs font-semibold text-emerald-700 bg-emerald-50 px-2 py-1 rounded-full">
                  Pro
                </span>
              )}
              <button
                onClick={() => {
                  logout();
                  navigate('/');
                }}
                className="btn-secondary !py-1.5"
              >
                Log out
              </button>
            </>
          ) : (
            <>
              <Link to="/pricing" className="text-gray-600 hover:text-gray-900">
                Pricing
              </Link>
              <Link to="/login" className="text-gray-600 hover:text-gray-900">
                Log in
              </Link>
              <Link to="/register" className="btn-primary !py-1.5">
                Get started
              </Link>
            </>
          )}
        </div>
      </div>
    </nav>
  );
}
