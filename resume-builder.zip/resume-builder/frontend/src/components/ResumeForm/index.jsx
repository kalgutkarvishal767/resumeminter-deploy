import { useState } from 'react';
import { FONT_OPTIONS } from '../../../../shared/templateRegistry.js';

// A single, pragmatic form component covering every resume section.
// It's intentionally kept in one file: every section follows the same
// "array of objects with add/update/remove" pattern, so splitting it into
// eight near-identical files would add navigation overhead without adding
// clarity. `onUpdate(patch)` merges `patch` into the parent's resume state
// (the parent debounces and persists it to the backend).

function Field({ label, children }) {
  return (
    <div>
      <label className="label">{label}</label>
      {children}
    </div>
  );
}

function SectionCard({ title, children, right }) {
  return (
    <div className="card p-4">
      <div className="flex items-center justify-between mb-3">
        <h3 className="font-semibold text-sm text-gray-800">{title}</h3>
        {right}
      </div>
      {children}
    </div>
  );
}

function ArrayEditor({ items, onChange, renderItem, emptyItem, addLabel }) {
  function update(index, patch) {
    const next = items.slice();
    next[index] = { ...next[index], ...patch };
    onChange(next);
  }
  function remove(index) {
    onChange(items.filter((_, i) => i !== index));
  }
  function add() {
    onChange([...(items || []), { ...emptyItem }]);
  }

  return (
    <div className="space-y-3">
      {(items || []).map((item, index) => (
        <div key={index} className="border border-gray-200 rounded-lg p-3 relative">
          <button
            onClick={() => remove(index)}
            className="absolute top-2 right-2 text-xs text-gray-400 hover:text-red-600"
            title="Remove"
            type="button"
          >
            ✕
          </button>
          {renderItem(item, (patch) => update(index, patch), index)}
        </div>
      ))}
      <button type="button" onClick={add} className="btn-secondary !py-1.5 text-xs">
        {addLabel}
      </button>
    </div>
  );
}

function BulletsEditor({ bullets, onChange }) {
  const list = bullets || [];
  return (
    <div className="mt-2">
      <label className="label">Highlights</label>
      {list.map((b, i) => (
        <div key={i} className="flex gap-2 mb-1.5">
          <input
            className="input"
            value={b}
            onChange={(e) => {
              const next = list.slice();
              next[i] = e.target.value;
              onChange(next);
            }}
            placeholder="e.g. Increased conversion rate by 18% through A/B testing"
          />
          <button
            type="button"
            className="text-gray-400 hover:text-red-600 text-sm px-1"
            onClick={() => onChange(list.filter((_, idx) => idx !== i))}
          >
            ✕
          </button>
        </div>
      ))}
      <button type="button" className="text-xs text-brand-600 font-semibold" onClick={() => onChange([...list, ''])}>
        + Add bullet point
      </button>
    </div>
  );
}

// Lets the user override the font family / font size used inside one resume
// section (e.g. make "Experience" bigger than "Certifications"). Writes into
// resume.sectionStyles[sectionKey], which shared/resumeHtmlRenderer.js turns
// into scoped CSS for both the live preview and the exported PDF.
function SectionStyleControls({ resume, onUpdate, sectionKey }) {
  const style = (resume.sectionStyles && resume.sectionStyles[sectionKey]) || {};

  function setStyle(patch) {
    onUpdate({
      sectionStyles: {
        ...(resume.sectionStyles || {}),
        [sectionKey]: { ...style, ...patch }
      }
    });
  }

  return (
    <div className="flex items-center gap-1.5">
      <select
        className="input !py-1 !text-xs !w-auto !pr-6"
        value={style.fontFamily || ''}
        onChange={(e) => setStyle({ fontFamily: e.target.value || undefined })}
        title="Font for this section"
      >
        <option value="">Default font</option>
        {FONT_OPTIONS.map((f) => (
          <option key={f.key} value={f.key}>
            {f.label}
          </option>
        ))}
      </select>
      <input
        type="number"
        className="input !py-1 !text-xs !w-14"
        min={8}
        max={28}
        placeholder="Size"
        value={style.fontSize || ''}
        onChange={(e) => setStyle({ fontSize: e.target.value ? Number(e.target.value) : undefined })}
        title="Font size (px) for this section"
      />
    </div>
  );
}

export default function ResumeForm({ resume, onUpdate }) {
  const [skillDraft, setSkillDraft] = useState('');

  function set(field, value) {
    onUpdate({ [field]: value });
  }
  function setPersonal(field, value) {
    onUpdate({ personalInfo: { ...resume.personalInfo, [field]: value } });
  }

  function addSkill() {
    const value = skillDraft.trim();
    if (!value) return;
    set('skills', [...(resume.skills || []), value]);
    setSkillDraft('');
  }

  return (
    <div className="space-y-4">
      <SectionCard title="Basics">
        <div className="grid grid-cols-2 gap-3">
          <Field label="Full name">
            <input className="input" value={resume.personalInfo.fullName} onChange={(e) => setPersonal('fullName', e.target.value)} />
          </Field>
          <Field label="Job title">
            <input className="input" value={resume.personalInfo.jobTitle} onChange={(e) => setPersonal('jobTitle', e.target.value)} />
          </Field>
          <Field label="Email">
            <input className="input" value={resume.personalInfo.email} onChange={(e) => setPersonal('email', e.target.value)} />
          </Field>
          <Field label="Phone">
            <input className="input" value={resume.personalInfo.phone} onChange={(e) => setPersonal('phone', e.target.value)} />
          </Field>
          <Field label="Location">
            <input className="input" value={resume.personalInfo.location} onChange={(e) => setPersonal('location', e.target.value)} />
          </Field>
          <Field label="Website / Portfolio">
            <input className="input" value={resume.personalInfo.website} onChange={(e) => setPersonal('website', e.target.value)} />
          </Field>
          <Field label="LinkedIn">
            <input className="input" value={resume.personalInfo.linkedin} onChange={(e) => setPersonal('linkedin', e.target.value)} />
          </Field>
          <Field label="Photo URL (optional)">
            <input className="input" value={resume.personalInfo.photoUrl} onChange={(e) => setPersonal('photoUrl', e.target.value)} />
          </Field>
        </div>
      </SectionCard>

      <SectionCard title="Summary" right={<SectionStyleControls resume={resume} onUpdate={onUpdate} sectionKey="summary" />}>
        <textarea
          className="input min-h-[90px]"
          value={resume.summary}
          onChange={(e) => set('summary', e.target.value)}
          placeholder="2-3 sentences summarizing your experience and what you're looking for."
        />
      </SectionCard>

      <SectionCard title="Experience" right={<SectionStyleControls resume={resume} onUpdate={onUpdate} sectionKey="experience" />}>
        <ArrayEditor
          items={resume.experience}
          onChange={(v) => set('experience', v)}
          emptyItem={{ company: '', role: '', location: '', startDate: '', endDate: '', current: false, bullets: [] }}
          addLabel="+ Add work experience"
          renderItem={(item, update) => (
            <div className="grid grid-cols-2 gap-2">
              <input className="input" placeholder="Role" value={item.role} onChange={(e) => update({ role: e.target.value })} />
              <input className="input" placeholder="Company" value={item.company} onChange={(e) => update({ company: e.target.value })} />
              <input className="input" placeholder="Location" value={item.location} onChange={(e) => update({ location: e.target.value })} />
              <div className="flex gap-2">
                <input className="input" placeholder="Start (e.g. Jan 2022)" value={item.startDate} onChange={(e) => update({ startDate: e.target.value })} />
                <input
                  className="input"
                  placeholder="End"
                  value={item.current ? '' : item.endDate}
                  disabled={item.current}
                  onChange={(e) => update({ endDate: e.target.value })}
                />
              </div>
              <label className="col-span-2 flex items-center gap-2 text-xs text-gray-600">
                <input type="checkbox" checked={!!item.current} onChange={(e) => update({ current: e.target.checked })} />
                I currently work here
              </label>
              <div className="col-span-2">
                <BulletsEditor bullets={item.bullets} onChange={(b) => update({ bullets: b })} />
              </div>
            </div>
          )}
        />
      </SectionCard>

      <SectionCard title="Education" right={<SectionStyleControls resume={resume} onUpdate={onUpdate} sectionKey="education" />}>
        <ArrayEditor
          items={resume.education}
          onChange={(v) => set('education', v)}
          emptyItem={{ school: '', degree: '', field: '', location: '', startDate: '', endDate: '', grade: '' }}
          addLabel="+ Add education"
          renderItem={(item, update) => (
            <div className="grid grid-cols-2 gap-2">
              <input className="input" placeholder="Degree" value={item.degree} onChange={(e) => update({ degree: e.target.value })} />
              <input className="input" placeholder="Field of study" value={item.field} onChange={(e) => update({ field: e.target.value })} />
              <input className="input" placeholder="School" value={item.school} onChange={(e) => update({ school: e.target.value })} />
              <input className="input" placeholder="Location" value={item.location} onChange={(e) => update({ location: e.target.value })} />
              <input className="input" placeholder="Start" value={item.startDate} onChange={(e) => update({ startDate: e.target.value })} />
              <input className="input" placeholder="End" value={item.endDate} onChange={(e) => update({ endDate: e.target.value })} />
              <input className="input col-span-2" placeholder="Grade / GPA (optional)" value={item.grade} onChange={(e) => update({ grade: e.target.value })} />
            </div>
          )}
        />
      </SectionCard>

      <SectionCard title="Skills" right={<SectionStyleControls resume={resume} onUpdate={onUpdate} sectionKey="skills" />}>
        <div className="flex flex-wrap gap-2 mb-3">
          {(resume.skills || []).map((s, i) => (
            <span key={i} className="text-xs bg-gray-100 px-2 py-1 rounded-full flex items-center gap-1">
              {s}
              <button
                type="button"
                className="text-gray-400 hover:text-red-600"
                onClick={() => set('skills', resume.skills.filter((_, idx) => idx !== i))}
              >
                ✕
              </button>
            </span>
          ))}
        </div>
        <div className="flex gap-2">
          <input
            className="input"
            placeholder="e.g. Project Management"
            value={skillDraft}
            onChange={(e) => setSkillDraft(e.target.value)}
            onKeyDown={(e) => e.key === 'Enter' && (e.preventDefault(), addSkill())}
          />
          <button type="button" className="btn-secondary" onClick={addSkill}>
            Add
          </button>
        </div>
      </SectionCard>

      <SectionCard title="Projects" right={<SectionStyleControls resume={resume} onUpdate={onUpdate} sectionKey="projects" />}>
        <ArrayEditor
          items={resume.projects}
          onChange={(v) => set('projects', v)}
          emptyItem={{ name: '', link: '', description: '', bullets: [] }}
          addLabel="+ Add project"
          renderItem={(item, update) => (
            <div className="space-y-2">
              <input className="input" placeholder="Project name" value={item.name} onChange={(e) => update({ name: e.target.value })} />
              <input className="input" placeholder="Link (optional)" value={item.link} onChange={(e) => update({ link: e.target.value })} />
              <textarea className="input" placeholder="Short description" value={item.description} onChange={(e) => update({ description: e.target.value })} />
              <BulletsEditor bullets={item.bullets} onChange={(b) => update({ bullets: b })} />
            </div>
          )}
        />
      </SectionCard>

      <SectionCard title="Certifications" right={<SectionStyleControls resume={resume} onUpdate={onUpdate} sectionKey="certifications" />}>
        <ArrayEditor
          items={resume.certifications}
          onChange={(v) => set('certifications', v)}
          emptyItem={{ name: '', issuer: '', date: '' }}
          addLabel="+ Add certification"
          renderItem={(item, update) => (
            <div className="grid grid-cols-3 gap-2">
              <input className="input" placeholder="Name" value={item.name} onChange={(e) => update({ name: e.target.value })} />
              <input className="input" placeholder="Issuer" value={item.issuer} onChange={(e) => update({ issuer: e.target.value })} />
              <input className="input" placeholder="Date" value={item.date} onChange={(e) => update({ date: e.target.value })} />
            </div>
          )}
        />
      </SectionCard>

      <SectionCard title="Languages" right={<SectionStyleControls resume={resume} onUpdate={onUpdate} sectionKey="languages" />}>
        <ArrayEditor
          items={resume.languages}
          onChange={(v) => set('languages', v)}
          emptyItem={{ name: '', level: '' }}
          addLabel="+ Add language"
          renderItem={(item, update) => (
            <div className="grid grid-cols-2 gap-2">
              <input className="input" placeholder="Language" value={item.name} onChange={(e) => update({ name: e.target.value })} />
              <input className="input" placeholder="Level (e.g. Fluent)" value={item.level} onChange={(e) => update({ level: e.target.value })} />
            </div>
          )}
        />
      </SectionCard>
    </div>
  );
}
