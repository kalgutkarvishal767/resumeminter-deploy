# Turning ResumeForge into a Real Business

This isn't legal, tax, or financial advice — it's a practical map of the
decisions and paperwork ahead, so you know what to look into and when. For
anything binding (business structure, tax filings, contracts), confirm with
a chartered accountant or lawyer before you act.

## 1. Business structure

To accept payments at all, you need at least one of:

- **Sole proprietorship** — simplest, no separate registration required to
  start; your personal PAN and bank account can be used for Razorpay KYC.
  Fine for validating the idea, but you're personally liable for the
  business, and it looks less credible to some customers/partners.
- **LLP or Private Limited Company** — more paperwork (MCA registration,
  annual filings), but limits your personal liability and is usually
  expected once you're doing real revenue or want to raise money later.

A common path: start as a sole proprietor to validate demand cheaply, then
convert to a Private Limited Company once revenue justifies the overhead.

## 2. GST — what actually triggers it

As of the current rules, a services business in India must register for GST
once turnover crosses **₹20 lakh/year** (₹10 lakh in special-category
states); below that, registration is optional. Two things worth knowing:

- Razorpay's activation checklist asks for a GST certificate **if you have
  one** — you can get activated as an unregistered sole proprietor below the
  threshold, but larger/registered entities will typically need one.
- Some B2B customers (and some payment aggregators) prefer or require a GST
  number regardless of the threshold, since it lets them claim input credit.

Rules and thresholds change; confirm current numbers with a CA before
treating this as final, especially once you're close to the threshold.

## 3. Legal pages you need before charging anyone

Razorpay (and basic good practice) expects these live on your site:

- **Terms of Service** — what the subscription includes, auto-renewal terms, acceptable use
- **Privacy Policy** — what data you collect (resumes contain real PII —
  names, emails, phone numbers, addresses), how it's stored, who it's shared
  with (Razorpay for payments, MongoDB Atlas for storage), and how a user can
  request deletion
- **Refund / Cancellation Policy** — be explicit: e.g. "cancel anytime, no
  refund for the current billing period" or whatever you decide

Because you're storing personal data of Indian users, also look into India's
**Digital Personal Data Protection Act (DPDP Act)** — at minimum you'll want
a clear consent flow and a way for a user to delete their account and data
(the `DELETE /api/resumes/:id` route exists; you'd want an account-deletion
flow too before launch).

## 4. Pricing strategy

Worth knowing going in: the site you linked as a reference (shriresume.com)
is actually **free** — it monetizes through optional paid resume-writing
services, not subscriptions. That's one valid model; yours (subscription for
downloads) is another, closer to how international players like Zety,
Novoresume, or Enhancv operate (they gate PDF/Word export behind a paid
plan, same as this build).

Rather than picking a number blind:

- Look at 4-5 direct competitors' pricing pages (Indian and international)
  for a sense of the range.
- Start with monthly and quarterly tiers (as scoped) and consider a
  discounted quarterly rate (e.g. quarterly = 2.5x monthly instead of 3x) to
  nudge people toward the stickier plan.
- A short free tier (this build gives free users 1 resume with no download —
  see `FREE_RESUME_LIMIT` in `backend/src/controllers/resumeController.js`)
  lets people experience the product before paying, which matters a lot for
  conversion.
- Treat your first price as a hypothesis. Track conversion rate (visitors →
  paid) and cancellation reasons, and be willing to adjust after real data
  comes in rather than guessing once and freezing it.

## 5. Getting the first users

- **SEO**: resume-related searches ("resume format for freshers", "ATS
  friendly resume template") have real volume; a blog with genuinely useful
  career-advice content is the standard way resume tools acquire organic
  traffic over time.
- **LinkedIn**: your exact audience lives there. Founder-led posts showing
  the templates, before/after resume makeovers, etc. tend to outperform ads
  early on.
- **Communities**: r/resumes, Indian job-seeker Telegram/WhatsApp groups,
  college placement cells — direct outreach where your users already are.
- **Launch platforms**: Product Hunt, IndieHackers — good for an initial
  spike and feedback, less reliable for sustained traffic.
- **Referral loop**: consider giving a free month for every friend referred
  who subscribes — cheap to build, and resume tools are naturally shared
  ("hey, I made mine on this").
- Paid ads (Google/Meta) are worth testing only after you've validated that
  free-to-paid conversion works — otherwise you're paying to find out your
  funnel is broken.

## 6. Metrics worth tracking from day one

- Signups → resumes created → first download attempt → subscribed (find the
  biggest drop-off first; that's your highest-leverage fix)
- Monthly Recurring Revenue (MRR) and churn rate once you have paying users
- Which templates get chosen most (you already have `templateId` on every
  Resume document — a simple aggregation query gives you this for free)

## 7. Operational basics before scaling spend

- Customer support channel (even just a monitored support email to start)
- A status page or at least an uptime monitor (see the deployment guide)
- A backup/restore drill you've actually tested — MongoDB Atlas free tier
  does *not* include automated backups; either upgrade to a paid tier for
  point-in-time recovery, or script periodic `mongodump` exports somewhere
  safe once you have real customer data worth protecting
