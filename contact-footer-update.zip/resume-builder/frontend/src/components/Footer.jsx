export default function Footer() {
  return (
    <footer className="border-t border-gray-200 bg-white">
      <div className="max-w-7xl mx-auto px-4 py-8 flex flex-col gap-6">
        <div className="flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-gray-500">
          <span className="font-semibold text-gray-700">Resume Minter</span>

          <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
            <a href="/faq.html" className="hover:text-gray-900">
              FAQ
            </a>
            <a href="/terms.html" className="hover:text-gray-900">
              Terms of Service
            </a>
            <a href="/privacy.html" className="hover:text-gray-900">
              Privacy Policy
            </a>
            <a href="/refund-policy.html" className="hover:text-gray-900">
              Refund &amp; Cancellation Policy
            </a>
          </div>

          <span>&copy; {new Date().getFullYear()} ResumeMinter Services. All rights reserved.</span>
        </div>

        {/* The email address is shown as plain, copyable text (not just a
            mailto link) because mailto: links silently do nothing for anyone
            without a default email app configured in their browser — showing
            the address itself means visitors can always reach us either way. */}
        <div className="border-t border-gray-100 pt-4 text-center text-sm text-gray-500">
          <span className="font-semibold text-gray-700">Contact Us: </span>
          Email us anytime at{' '}
          <a href="mailto:services@resumeminter.com" className="font-semibold text-brand-600 hover:underline">
            services@resumeminter.com
          </a>{' '}
          — whether it's a billing question, a bug report, or general feedback, that's the fastest way to reach us.
        </div>
      </div>
    </footer>
  );
}
