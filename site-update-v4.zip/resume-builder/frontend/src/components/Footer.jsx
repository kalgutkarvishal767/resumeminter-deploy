export default function Footer() {
  return (
    <footer className="border-t border-gray-200 bg-white">
      <div className="max-w-7xl mx-auto px-4 py-8 flex flex-col sm:flex-row items-center justify-between gap-4 text-sm text-gray-500">
        <span className="font-semibold text-gray-700">Resume Minter</span>

        <div className="flex flex-wrap items-center justify-center gap-x-6 gap-y-2">
          <a href="/terms.html" className="hover:text-gray-900">
            Terms of Service
          </a>
          <a href="/privacy.html" className="hover:text-gray-900">
            Privacy Policy
          </a>
          <a href="/refund-policy.html" className="hover:text-gray-900">
            Refund &amp; Cancellation Policy
          </a>
          <a href="mailto:services@resumeminter.com" className="hover:text-gray-900">
            Contact Us
          </a>
        </div>

        <span>&copy; {new Date().getFullYear()} ResumeMinter Services. All rights reserved.</span>
      </div>
    </footer>
  );
}
