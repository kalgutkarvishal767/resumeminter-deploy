import { Router } from 'express';
import { requireAuth } from '../middleware/auth.js';
import { requireActiveSubscription } from '../middleware/subscription.js';
import { exportPdf, exportDocx } from '../controllers/exportController.js';

const router = Router();

router.use(requireAuth);

// PDF: free users get exactly one download (enforced inside exportPdf itself,
// since it needs to check/increment a counter, not just a boolean).
router.get('/:id/pdf', exportPdf);

// Word/DOCX: never free, always requires an active subscription.
router.get('/:id/docx', requireActiveSubscription, exportDocx);

export default router;
