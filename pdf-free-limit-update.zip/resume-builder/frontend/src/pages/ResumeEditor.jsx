import { useEffect, useRef, useState } from 'react';
import { useNavigate, useParams, Link } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import ResumeForm from '../components/ResumeForm/index.jsx';
import ResumePreview from '../components/ResumePreview.jsx';
import { TEMPLATES, getTemplateById } from '../../../shared/templateRegistry.js';

const SAVE_DEBOUNCE_MS = 900;

export default function ResumeEditor() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { user, isSubscribed, refreshUser } = useAuth();

  const [resume, setResume] = useState(null);
  const [saving, setSaving] = useState(false);
  const [exportError, setExportError] = useState('');
  const [exporting, setExporting] = useState(null);
  const [showTemplatePicker, setShowTemplatePicker] = useState(false);
  const saveTimer = useRef(null);

  useEffect(() => {
    api.get(`/resumes/${id}`).then(({ data }) => setResume(data.resume));
  }, [id]);

  function scheduleSave(next) {
    setResume(next);
    setSaving(true);
    clearTimeout(saveTimer.current);
    saveTimer.current = setTimeout(async () => {
      try {
        await api.put(`/resumes/${id}`, next);
      } finally {
        setSaving(false);
      }
    }, SAVE_DEBOUNCE_MS);
  }

  function onUpdate(patch) {
    scheduleSave({ ...resume, ...patch });
  }

  function changeTemplate(templateId) {
    const template = getTemplateById(templateId);
    scheduleSave({ ...resume, templateId, accentColor: template.defaultAccentColor });
    setShowTemplatePicker(false);
  }

  // Word/DOCX is never available to free accounts — the button below routes
  // straight to /pricing for them without ever calling the API.
  function handleWordClick() {
    if (!isSubscribed) {
      navigate('/pricing');
      return;
    }
    handleExport('docx');
  }

  async function handleExport(format) {
    setExportError('');
    setExporting(format);
    try {
      const response = await api.get(`/export/${id}/${format}`, { responseType: 'blob' });
      const blob = new Blob([response.data]);
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `${resume.title || 'resume'}.${format === 'pdf' ? 'pdf' : 'docx'}`;
      document.body.appendChild(a);
      a.click();
      a.remove();
      window.URL.revokeObjectURL(url);

      // Free accounts' PDF quota changed server-side; refresh so the button
      // and banner below reflect the new remaining-downloads count.
      if (format === 'pdf' && !isSubscribed) {
        refreshUser();
      }
    } catch (err) {
      if (err.response?.status === 402) {
        // With responseType: 'blob', axios still delivers a JSON error body
        // as a Blob — read it back out so we can show the server's exact
        // "please upgrade" message instead of a generic one.
        let message = 'You\'ve used your free PDF download. Please upgrade to keep downloading.';
        try {
          const text = await err.response.data.text();
          const parsed = JSON.parse(text);
          if (parsed?.error) message = parsed.error;
        } catch {
          // Non-JSON body (shouldn't happen) — fall back to the default message above.
        }
        setExportError(message);
      } else {
        setExportError('Failed to export. Please try again.');
      }
    } finally {
      setExporting(null);
    }
  }

  const freeDownloadsRemaining = user
    ? Math.max(0, (user.freePdfDownloadLimit ?? 1) - (user.freePdfDownloadsUsed ?? 0))
    : 0;

  if (!resume) return <div className="p-10 text-center text-gray-500">Loading resume…</div>;

  return (
    <div className="max-w-7xl mx-auto px-4 py-6">
      <div className="flex items-center justify-between mb-4 gap-3">
        <div className="flex items-center gap-3 flex-1 min-w-0">
          <Link to="/dashboard" className="text-sm text-gray-500 hover:text-gray-800 shrink-0">
            ← Back
          </Link>
          <input
            className="text-lg font-semibold bg-transparent border-b border-transparent hover:border-gray-300 focus:border-brand-500 focus:outline-none flex-1 min-w-0"
            value={resume.title}
            onChange={(e) => onUpdate({ title: e.target.value })}
          />
        </div>
        <span className="text-xs text-gray-400 shrink-0">{saving ? 'Saving…' : 'Saved'}</span>
        <div className="flex gap-2 shrink-0">
          <button className="btn-secondary !py-1.5" onClick={() => setShowTemplatePicker((v) => !v)}>
            Change template
          </button>
          <input
            type="color"
            className="w-9 h-9 rounded-lg border border-gray-300 cursor-pointer"
            value={resume.accentColor}
            onChange={(e) => onUpdate({ accentColor: e.target.value })}
            title="Accent color"
          />
          <button className="btn-secondary !py-1.5" disabled={exporting === 'pdf'} onClick={() => handleExport('pdf')}>
            {exporting === 'pdf' ? 'Preparing…' : 'Download PDF'}
          </button>
          <button
            className={`btn-primary !py-1.5 ${!isSubscribed ? 'opacity-50 cursor-not-allowed' : ''}`}
            disabled={exporting === 'docx'}
            onClick={handleWordClick}
            title={!isSubscribed ? 'Word downloads require an active subscription' : ''}
          >
            {exporting === 'docx' ? 'Preparing…' : 'Download Word'}
          </button>
        </div>
      </div>

      {!isSubscribed && (
        <div className="card p-3 mb-4 bg-amber-50 border-amber-200 text-sm text-amber-800">
          {freeDownloadsRemaining > 0
            ? `You have ${freeDownloadsRemaining} free PDF download remaining. Word (.docx) downloads require an active subscription.`
            : 'You\'ve used your free PDF download and Word (.docx) downloads always require a subscription.'}{' '}
          <Link to="/pricing" className="font-semibold underline">Upgrade now</Link>.
        </div>
      )}
      {exportError && (
        <div className="card p-3 mb-4 bg-red-50 border-red-200 text-sm text-red-700">
          {exportError}{' '}
          <Link to="/pricing" className="font-semibold underline">Upgrade now</Link>.
        </div>
      )}

      {showTemplatePicker && (
        <div className="card p-4 mb-4 grid grid-cols-4 sm:grid-cols-8 gap-2">
          {TEMPLATES.map((t) => (
            <button
              key={t.id}
              onClick={() => changeTemplate(t.id)}
              className={`h-14 rounded-md text-[10px] text-white font-semibold flex items-center justify-center px-1 text-center ${
                t.id === resume.templateId ? 'ring-2 ring-offset-2 ring-brand-500' : ''
              }`}
              style={{ background: t.defaultAccentColor }}
              title={t.name}
            >
              {t.name}
            </button>
          ))}
        </div>
      )}

      <div className="grid lg:grid-cols-[420px_1fr] gap-6">
        <div>
          <ResumeForm resume={resume} onUpdate={onUpdate} />
        </div>
        <div className="lg:sticky lg:top-6 self-start">
          <ResumePreview resume={resume} />
        </div>
      </div>
    </div>
  );
}
