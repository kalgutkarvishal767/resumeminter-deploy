import { Router } from 'express';
import multer from 'multer';
import { requireAuth } from '../middleware/auth.js';
import {
  listResumes,
  getResume,
  createResume,
  importResume,
  updateResume,
  deleteResume,
  duplicateResume
} from '../controllers/resumeController.js';

const router = Router();

router.use(requireAuth);

// Uploaded resumes are parsed in memory (never written to disk) and capped
// at 8MB, which is generous for a text-based PDF/DOCX resume.
const upload = multer({
  storage: multer.memoryStorage(),
  limits: { fileSize: 8 * 1024 * 1024 },
  fileFilter: (req, file, cb) => {
    const allowedExt = /\.(pdf|docx)$/i.test(file.originalname || '');
    const allowedMime = [
      'application/pdf',
      'application/vnd.openxmlformats-officedocument.wordprocessingml.document'
    ].includes(file.mimetype);
    if (allowedExt || allowedMime) return cb(null, true);
    cb(new Error('UNSUPPORTED_FILE_TYPE'));
  }
});

// Wraps multer so its errors (bad file type, too large) come back as a clean
// 400 JSON response instead of falling through to the generic 500 handler.
function handleUpload(req, res, next) {
  upload.single('resume')(req, res, (err) => {
    if (err) {
      const message =
        err.code === 'LIMIT_FILE_SIZE'
          ? 'That file is too large (8MB max).'
          : 'Please upload a PDF or Word (.docx) file.';
      return res.status(400).json({ error: message });
    }
    next();
  });
}

router.get('/', listResumes);
router.post('/', createResume);
router.post('/import', handleUpload, importResume);
router.get('/:id', getResume);
router.put('/:id', updateResume);
router.delete('/:id', deleteResume);
router.post('/:id/duplicate', duplicateResume);

export default router;
