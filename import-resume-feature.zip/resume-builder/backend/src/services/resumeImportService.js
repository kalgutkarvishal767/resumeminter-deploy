// Best-effort "import an existing resume" pipeline: pulls plain text out of an
// uploaded PDF or Word (.docx) file, then uses pattern-matching (section
// headings, date ranges, bullet characters, email/phone shapes) to guess how
// that text maps onto our structured resume fields.
//
// This is a heuristic, not an AI model — it does well on cleanly-formatted,
// conventional resumes and can misfile content on unusual layouts or creative
// formats. The frontend always opens the result in the normal editor so the
// user can review and correct anything before saving, rather than trusting
// the guess blindly.

import pdfParse from 'pdf-parse';
import mammoth from 'mammoth';

const SECTION_PATTERNS = [
  { key: 'summary', re: /^(summary|profile|objective|about me|career objective)\s*:?$/i },
  { key: 'experience', re: /^(experience|work experience|employment history|professional experience|work history)\s*:?$/i },
  { key: 'education', re: /^(education|academic background|academics|educational qualifications)\s*:?$/i },
  { key: 'skills', re: /^(skills|technical skills|core competencies|key skills|areas of expertise)\s*:?$/i },
  { key: 'projects', re: /^(projects|personal projects|key projects|academic projects)\s*:?$/i },
  { key: 'certifications', re: /^(certifications?|certificates?|licenses?( and certifications)?)\s*:?$/i },
  { key: 'languages', re: /^(languages)\s*:?$/i }
];

const EMAIL_RE = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/;
const PHONE_RE = /(\+?\d{1,3}[\s.-]?)?\(?\d{3,5}\)?[\s.-]?\d{3,4}[\s.-]?\d{3,4}/;
const LINKEDIN_RE = /(?:https?:\/\/)?(?:www\.)?linkedin\.com\/\S+/i;
const WEBSITE_RE = /\b(?:https?:\/\/)?(?:www\.)?[a-z0-9-]+\.(?:com|dev|io|me|net|org|in|co)\b\S*/i;
const BULLET_RE = /^[•●▪◦‣∙·o]\s+|^[-*]\s+/;
const MONTH = '(?:jan|feb|mar|apr|may|jun|jul|aug|sep|oct|nov|dec)[a-z]*\\.?';
const DATE_RANGE_RE = new RegExp(
  `(${MONTH}\\s*\\d{4}|\\d{4})\\s*(?:-|–|—|to)\\s*(present|current|now|${MONTH}\\s*\\d{4}|\\d{4})`,
  'i'
);
const YEAR_RE = /\b(19|20)\d{2}\b/;

function cleanLines(text) {
  return text
    .replace(/\r\n/g, '\n')
    .split('\n')
    .map((l) => l.replace(/\s+/g, ' ').trim())
    .filter((l, i, arr) => !(l === '' && arr[i - 1] === '')); // collapse repeated blank lines
}

function isLikelySectionHeading(line) {
  if (!line || line.length > 45) return null;
  for (const { key, re } of SECTION_PATTERNS) {
    if (re.test(line.trim())) return key;
  }
  return null;
}

function extractContactBlock(lines) {
  const personalInfo = { fullName: '', jobTitle: '', email: '', phone: '', location: '', website: '', linkedin: '' };
  const headLines = lines.slice(0, 15).filter(Boolean);

  for (const line of headLines) {
    if (!personalInfo.email) {
      const m = line.match(EMAIL_RE);
      if (m) personalInfo.email = m[0];
    }
    if (!personalInfo.linkedin) {
      const m = line.match(LINKEDIN_RE);
      if (m) personalInfo.linkedin = m[0];
    }
    if (!personalInfo.phone) {
      const m = line.match(PHONE_RE);
      // Avoid matching plain years or short numbers as phone numbers.
      if (m && m[0].replace(/\D/g, '').length >= 7) personalInfo.phone = m[0].trim();
    }
    if (!personalInfo.website && WEBSITE_RE.test(line) && !EMAIL_RE.test(line) && !LINKEDIN_RE.test(line)) {
      const m = line.match(WEBSITE_RE);
      if (m) personalInfo.website = m[0];
    }
  }

  // Name: the first short line that isn't itself an email/phone/URL and
  // doesn't look like a section heading.
  for (const line of headLines) {
    if (
      line &&
      line.length <= 60 &&
      !EMAIL_RE.test(line) &&
      !PHONE_RE.test(line.replace(/\s/g, '')) &&
      !LINKEDIN_RE.test(line) &&
      !WEBSITE_RE.test(line) &&
      !isLikelySectionHeading(line)
    ) {
      personalInfo.fullName = line.replace(/[|,]+$/, '').trim();
      break;
    }
  }

  // Job title: next short line after the name, if it doesn't look like
  // contact info or an address (has a comma-separated "City, State" shape).
  const nameIdx = headLines.indexOf(personalInfo.fullName);
  if (nameIdx !== -1 && headLines[nameIdx + 1]) {
    const candidate = headLines[nameIdx + 1];
    if (
      candidate.length <= 70 &&
      !EMAIL_RE.test(candidate) &&
      !PHONE_RE.test(candidate.replace(/\s/g, '')) &&
      !LINKEDIN_RE.test(candidate) &&
      !isLikelySectionHeading(candidate)
    ) {
      personalInfo.jobTitle = candidate;
    }
  }

  // Location: a short comma-separated line near the top with no digits
  // (e.g. "Bengaluru, India"), distinct from the name/job title lines.
  for (const line of headLines) {
    if (
      line !== personalInfo.fullName &&
      line !== personalInfo.jobTitle &&
      /^[A-Za-z .]+,\s*[A-Za-z .]+$/.test(line) &&
      line.length <= 50
    ) {
      personalInfo.location = line;
      break;
    }
  }

  return personalInfo;
}

function splitIntoSections(lines) {
  const sections = { _preamble: [] };
  let current = '_preamble';
  for (const line of lines) {
    const heading = isLikelySectionHeading(line);
    if (heading) {
      current = heading;
      sections[current] = sections[current] || [];
      continue;
    }
    sections[current] = sections[current] || [];
    sections[current].push(line);
  }
  return sections;
}

function parseSummary(lines = []) {
  return lines.filter(Boolean).join(' ').replace(/\s+/g, ' ').trim();
}

// Shared by Experience/Projects: groups lines into entries wherever a
// date-range appears, treating that line as the entry's header and any
// following bullet/plain lines (until the next date-range) as its details.
function groupByDateRanges(lines) {
  const entries = [];
  let current = null;

  for (const line of lines) {
    if (!line) continue;
    const dateMatch = line.match(DATE_RANGE_RE);
    if (dateMatch) {
      if (current) entries.push(current);
      current = { headerLine: line, dateRange: dateMatch, bullets: [] };
      continue;
    }
    if (!current) {
      // Content before any date range — start an entry anyway so nothing is lost.
      current = { headerLine: line, dateRange: null, bullets: [] };
      continue;
    }
    if (BULLET_RE.test(line)) {
      current.bullets.push(line.replace(BULLET_RE, '').trim());
    } else if (!current.dateRange && !current.secondLine) {
      // The line right after a headerless header is often the company/date line.
      current.secondLine = line;
    } else {
      current.bullets.push(line);
    }
  }
  if (current) entries.push(current);
  return entries;
}

function splitHeaderLine(headerLine, dateMatch) {
  let rest = headerLine;
  if (dateMatch) rest = rest.replace(dateMatch[0], '').trim();
  rest = rest.replace(/[|,–—-]+$/, '').trim();
  const parts = rest.split(/\s*[|–—,]\s*/).filter(Boolean);
  return parts;
}

function parseExperience(lines = []) {
  const entries = groupByDateRanges(lines);
  return entries.map((entry) => {
    const parts = splitHeaderLine(entry.headerLine, entry.dateRange);
    const role = parts[0] || entry.headerLine.trim();
    const company = parts[1] || entry.secondLine || '';
    const location = parts[2] || '';
    let startDate = '';
    let endDate = '';
    let current = false;
    if (entry.dateRange) {
      startDate = entry.dateRange[1] || '';
      const end = (entry.dateRange[2] || '').toLowerCase();
      if (end === 'present' || end === 'current' || end === 'now') {
        current = true;
      } else {
        endDate = entry.dateRange[2] || '';
      }
    }
    return {
      role,
      company,
      location,
      startDate,
      endDate,
      current,
      bullets: entry.bullets.filter(Boolean)
    };
  });
}

function parseEducation(lines = []) {
  const entries = groupByDateRanges(lines);
  return entries.map((entry) => {
    const parts = splitHeaderLine(entry.headerLine, entry.dateRange);
    // Common shapes: "Degree | School | Location" (3 parts) or
    // "Degree, Field | School | Location" (4 parts). Map positionally based
    // on how many segments we actually found, rather than assuming 3 always.
    let degree = parts[0] || entry.headerLine.trim();
    let field = '';
    let school = entry.secondLine || '';
    let location = '';
    if (parts.length >= 4) {
      [degree, field, school, location] = parts;
    } else if (parts.length === 3) {
      [degree, school, location] = parts;
    } else if (parts.length === 2) {
      [degree, school] = parts;
    }
    let startDate = '';
    let endDate = '';
    if (entry.dateRange) {
      startDate = entry.dateRange[1] || '';
      endDate = /present|current|now/i.test(entry.dateRange[2] || '') ? '' : entry.dateRange[2] || '';
    }
    return { degree, field, school, location, startDate, endDate, grade: '' };
  });
}

function parseProjects(lines = []) {
  const entries = groupByDateRanges(lines);
  return entries.map((entry) => {
    const parts = splitHeaderLine(entry.headerLine, entry.dateRange);
    return {
      name: parts[0] || entry.headerLine.trim(),
      link: '',
      description: entry.secondLine || '',
      bullets: entry.bullets.filter(Boolean)
    };
  });
}

function parseSkills(lines = []) {
  return lines
    .join(', ')
    .split(/[,;|•●▪\n]/)
    .map((s) => s.trim())
    .filter((s) => s && s.length <= 40);
}

function parseCertifications(lines = []) {
  return lines
    .filter(Boolean)
    .map((line) => {
      const clean = line.replace(BULLET_RE, '');
      const yearMatch = clean.match(YEAR_RE);
      // Deliberately split on commas/pipes only, not plain hyphens — a
      // certification title itself often contains a hyphen (e.g. "AWS
      // Certified Solutions Architect - Associate"), which a hyphen-aware
      // split would incorrectly chop into the issuer field.
      const parts = clean.split(/\s*[,|]\s*/).filter(Boolean);
      const nonYearParts = parts.filter((p) => !YEAR_RE.test(p) || p.replace(YEAR_RE, '').trim().length > 0);
      return {
        name: nonYearParts[0] || clean.trim(),
        issuer: nonYearParts[1] && !YEAR_RE.test(nonYearParts[1]) ? nonYearParts[1] : '',
        date: yearMatch ? yearMatch[0] : ''
      };
    });
}

function parseLanguages(lines = []) {
  return lines
    .join(', ')
    .split(/[,;\n]/)
    .map((s) => s.trim())
    .filter(Boolean)
    .map((entry) => {
      const m = entry.match(/^(.+?)\s*[\(\-–]\s*([A-Za-z]+)\)?$/);
      return m ? { name: m[1].trim(), level: m[2].trim() } : { name: entry, level: '' };
    });
}

/**
 * Turns raw extracted resume text into a best-effort structured object
 * matching the shape of our Resume model. Always returns a complete,
 * well-formed object (falling back to empty fields) so the caller can save
 * it directly and let the user fill in gaps in the editor.
 */
export function parseResumeText(rawText) {
  const lines = cleanLines(rawText);
  const personalInfo = extractContactBlock(lines);
  const sections = splitIntoSections(lines);

  // If we couldn't find ANY recognizable section headings, don't lose the
  // person's content — dump everything after the contact block into the
  // summary so they can manually re-sort it in the editor.
  const foundAnySection = Object.keys(sections).some((k) => k !== '_preamble');

  return {
    personalInfo,
    summary: foundAnySection ? parseSummary(sections.summary) : parseSummary(lines.slice(3)),
    experience: parseExperience(sections.experience),
    education: parseEducation(sections.education),
    skills: parseSkills(sections.skills),
    projects: parseProjects(sections.projects),
    certifications: parseCertifications(sections.certifications),
    languages: parseLanguages(sections.languages)
  };
}

/**
 * Extracts plain text from an uploaded PDF or DOCX file buffer.
 * Throws a descriptive error for unsupported types.
 */
export async function extractTextFromFile(buffer, mimetype, originalname) {
  const isPdf = mimetype === 'application/pdf' || /\.pdf$/i.test(originalname || '');
  const isDocx =
    mimetype === 'application/vnd.openxmlformats-officedocument.wordprocessingml.document' ||
    /\.docx$/i.test(originalname || '');

  if (isPdf) {
    const data = await pdfParse(buffer);
    return data.text || '';
  }
  if (isDocx) {
    const result = await mammoth.extractRawText({ buffer });
    return result.value || '';
  }
  throw new Error('UNSUPPORTED_FILE_TYPE');
}
