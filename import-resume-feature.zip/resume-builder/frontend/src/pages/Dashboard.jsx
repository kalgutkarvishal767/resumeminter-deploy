import { useEffect, useRef, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { api } from '../api/client.js';
import { useAuth } from '../context/AuthContext.jsx';
import { TEMPLATES } from '../../../shared/templateRegistry.js';

function accentFor(templateId) {
  return TEMPLATES.find((t) => t.id === templateId)?.defaultAccentColor || '#7c3aed';
}

export default function Dashboard() {
  const [resumes, setResumes] = useState([]);
  const [loading, setLoading] = useState(true);
  const [importing, setImporting] = useState(false);
  const [importError, setImportError] = useState('');
  const { isSubscribed } = useAuth();
  const navigate = useNavigate();
  const fileInputRef = useRef(null);

  async function load() {
    setLoading(true);
    const { data } = await api.get('/resumes');
    setResumes(data.resumes);
    setLoading(false);
  }

  useEffect(() => {
    load();
  }, []);

  async function handleDelete(id) {
    if (!confirm('Delete this resume? This cannot be undone.')) return;
    await api.delete(`/resumes/${id}`);
    load();
  }

  async function handleDuplicate(id) {
    try {
      await api.post(`/resumes/${id}/duplicate`);
      load();
    } catch (err) {
      if (err.response?.data?.code === 'SUBSCRIPTION_REQUIRED') {
        navigate('/pricing');
      }
    }
  }

  function handleImportClick() {
    setImportError('');
    fileInputRef.current?.click();
  }

  async function handleFileSelected(e) {
    const file = e.target.files?.[0];
    e.target.value = ''; // allow re-selecting the same file later
    if (!file) return;

    if (!/\.(pdf|docx)$/i.test(file.name)) {
      setImportError('Please choose a PDF or Word (.docx) file.');
      return;
    }

    setImportError('');
    setImporting(true);
    try {
      const formData = new FormData();
      formData.append('resume', file);
      const { data } = await api.post('/resumes/import', formData);
      // Send them straight into the editor to review what was extracted —
      // the parser does its best, but the user should check names, dates,
      // and section placement before relying on it.
      navigate(`/resumes/${data.resume._id}`);
    } catch (err) {
      if (err.response?.data?.code === 'SUBSCRIPTION_REQUIRED') {
        navigate('/pricing');
        return;
      }
      setImportError(err.response?.data?.error || 'Failed to import that resume. Please try again.');
    } finally {
      setImporting(false);
    }
  }

  return (
    <div className="max-w-5xl mx-auto px-4 py-10">
      <div className="flex items-center justify-between mb-4 flex-wrap gap-3">
        <h1 className="text-2xl font-bold">My Resumes</h1>
        <div className="flex gap-2">
          <input
            ref={fileInputRef}
            type="file"
            accept=".pdf,.docx,application/pdf,application/vnd.openxmlformats-officedocument.wordprocessingml.document"
            className="hidden"
            onChange={handleFileSelected}
          />
          <button className="btn-secondary" onClick={handleImportClick} disabled={importing}>
            {importing ? 'Importing…' : 'Import Existing Resume'}
          </button>
          <Link to="/templates" className="btn-primary">
            + New Resume
          </Link>
        </div>
      </div>

      {importError && (
        <div className="card p-3 mb-4 bg-red-50 border-red-200 text-sm text-red-700">{importError}</div>
      )}

      <p className="text-xs text-gray-400 mb-6">
        Import Existing Resume reads a PDF or Word file and does its best to fill in your details automatically —
        you'll land in the editor right after so you can review and fix anything before saving.
      </p>

      {!isSubscribed && (
        <div className="card p-4 mb-6 bg-amber-50 border-amber-200 flex items-center justify-between">
          <p className="text-sm text-amber-800">
            You're on the free plan (1 resume, no downloads). Subscribe to unlock unlimited resumes and PDF/Word
            downloads.
          </p>
          <Link to="/pricing" className="btn-primary !py-1.5 shrink-0 ml-4">
            Upgrade
          </Link>
        </div>
      )}

      {loading ? (
        <p className="text-gray-500">Loading…</p>
      ) : resumes.length === 0 ? (
        <div className="card p-10 text-center text-gray-500">
          You don't have any resumes yet. <Link to="/templates" className="text-brand-600 font-semibold">Create one</Link>{' '}
          or use <span className="font-semibold">Import Existing Resume</span> above.
        </div>
      ) : (
        <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-5">
          {resumes.map((r) => {
            const accent = accentFor(r.templateId);
            return (
              <div
                key={r._id}
                className="card overflow-hidden flex flex-col justify-between hover:shadow-lg hover:-translate-y-0.5 transition-all"
              >
                <div className="h-2" style={{ background: `linear-gradient(90deg, ${accent}, ${accent}88)` }} />
                <div className="p-4 flex-1">
                  <h3 className="font-semibold">{r.title}</h3>
                  <p className="text-xs text-gray-500 mt-1">Template: {r.templateId}</p>
                  <p className="text-xs text-gray-400">Updated {new Date(r.updatedAt).toLocaleDateString()}</p>
                </div>
                <div className="flex gap-2 p-4 pt-0">
                  <Link to={`/resumes/${r._id}`} className="btn-primary !py-1.5 flex-1 text-center">
                    Edit
                  </Link>
                  <button onClick={() => handleDuplicate(r._id)} className="btn-secondary !py-1.5">
                    Duplicate
                  </button>
                  <button onClick={() => handleDelete(r._id)} className="btn-secondary !py-1.5 text-red-600">
                    Delete
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
