import Resume from '../models/Resume.js';
import { getTemplateById } from '../templates/templateRegistry.js';
import { extractTextFromFile, parseResumeText } from '../services/resumeImportService.js';

const FREE_RESUME_LIMIT = 1; // non-subscribers can keep 1 resume in progress

export async function listResumes(req, res) {
  const resumes = await Resume.find({ user: req.user._id }).sort({ updatedAt: -1 });
  res.json({ resumes });
}

export async function getResume(req, res) {
  const resume = await Resume.findOne({ _id: req.params.id, user: req.user._id });
  if (!resume) return res.status(404).json({ error: 'Resume not found' });
  res.json({ resume });
}

export async function createResume(req, res) {
  const isSubscribed = req.user.hasActiveSubscription();
  if (!isSubscribed) {
    const count = await Resume.countDocuments({ user: req.user._id });
    if (count >= FREE_RESUME_LIMIT) {
      return res.status(402).json({
        error: `Free accounts are limited to ${FREE_RESUME_LIMIT} resume. Subscribe to create more.`,
        code: 'SUBSCRIPTION_REQUIRED'
      });
    }
  }

  const { title, templateId } = req.body;
  const template = getTemplateById(templateId) || getTemplateById('classic-01');

  const resume = new Resume({
    user: req.user._id,
    title: title || 'Untitled Resume',
    templateId: template.id,
    accentColor: template.defaultAccentColor
  });
  await resume.save();
  res.status(201).json({ resume });
}

// Lets a user upload an existing PDF/Word resume instead of typing everything
// from scratch. Text is extracted from the file, then run through a
// pattern-matching parser (see resumeImportService.js) that does its best to
// place content into the right fields — contact info, work history, skills,
// etc. The result is saved as a normal resume and handed back to the
// frontend, which opens it directly in the editor so the user can review and
// fix anything the parser guessed wrong before relying on it.
//
// Unlike creating a resume from scratch, importing is intentionally NOT
// subject to the free-tier resume-count limit — it's a free, no-subscription
// feature for every account, by design.
export async function importResume(req, res) {
  try {
    if (!req.file) {
      return res.status(400).json({ error: 'No file was uploaded.' });
    }

    let rawText;
    try {
      rawText = await extractTextFromFile(req.file.buffer, req.file.mimetype, req.file.originalname);
    } catch (err) {
      return res.status(400).json({ error: 'Please upload a PDF or Word (.docx) file.' });
    }

    if (!rawText || !rawText.trim()) {
      return res.status(422).json({
        error:
          "We couldn't find any readable text in that file — it may be a scanned image rather than a text-based document. Please try a different file or enter your details manually."
      });
    }

    const extracted = parseResumeText(rawText);
    const template = getTemplateById('classic-01');

    const resume = new Resume({
      user: req.user._id,
      title: extracted.personalInfo.fullName ? `${extracted.personalInfo.fullName}'s Resume` : 'Imported Resume',
      templateId: template.id,
      accentColor: template.defaultAccentColor,
      personalInfo: extracted.personalInfo,
      summary: extracted.summary,
      experience: extracted.experience,
      education: extracted.education,
      skills: extracted.skills,
      projects: extracted.projects,
      certifications: extracted.certifications,
      languages: extracted.languages
    });
    await resume.save();
    res.status(201).json({ resume, imported: true });
  } catch (err) {
    console.error('[resume] import error', err);
    res.status(500).json({ error: 'Failed to import your resume. Please try again or enter your details manually.' });
  }
}

export async function updateResume(req, res) {
  const resume = await Resume.findOne({ _id: req.params.id, user: req.user._id });
  if (!resume) return res.status(404).json({ error: 'Resume not found' });

  const allowedFields = [
    'title',
    'templateId',
    'accentColor',
    'fontFamily',
    'personalInfo',
    'summary',
    'experience',
    'education',
    'skills',
    'languages',
    'projects',
    'certifications',
    'sectionOrder'
  ];

  for (const field of allowedFields) {
    if (req.body[field] !== undefined) {
      resume[field] = req.body[field];
    }
  }

  await resume.save();
  res.json({ resume });
}

export async function deleteResume(req, res) {
  const resume = await Resume.findOneAndDelete({ _id: req.params.id, user: req.user._id });
  if (!resume) return res.status(404).json({ error: 'Resume not found' });
  res.json({ success: true });
}

export async function duplicateResume(req, res) {
  const isSubscribed = req.user.hasActiveSubscription();
  if (!isSubscribed) {
    const count = await Resume.countDocuments({ user: req.user._id });
    if (count >= FREE_RESUME_LIMIT) {
      return res.status(402).json({
        error: `Free accounts are limited to ${FREE_RESUME_LIMIT} resume. Subscribe to create more.`,
        code: 'SUBSCRIPTION_REQUIRED'
      });
    }
  }

  const original = await Resume.findOne({ _id: req.params.id, user: req.user._id });
  if (!original) return res.status(404).json({ error: 'Resume not found' });

  const copy = original.toObject();
  delete copy._id;
  delete copy.createdAt;
  delete copy.updatedAt;
  copy.title = `${copy.title} (copy)`;

  const resume = new Resume(copy);
  await resume.save();
  res.status(201).json({ resume });
}
