// A single canned resume used to render realistic-looking template thumbnails
// on the template picker page (and anywhere else we want to preview a
// template without a real user's data). Deliberately generic/placeholder.
export const SAMPLE_RESUME = {
  personalInfo: {
    fullName: 'Alex Morgan',
    jobTitle: 'Marketing & Sales Professional',
    email: 'alex.morgan@email.com',
    phone: '+91 98765 43210',
    location: 'Mumbai, India',
    linkedin: 'linkedin.com/in/alexmorgan'
  },
  summary:
    'Results-driven marketing professional with 6+ years of experience building and scaling brand campaigns across digital and offline channels.',
  experience: [
    {
      company: 'Solvent Solutions Pvt Ltd',
      role: 'Marketing Manager',
      location: 'Mumbai',
      startDate: 'Jul 2021',
      current: true,
      bullets: [
        'Led a cross-functional team to launch 12 campaigns, growing qualified leads by 38%.',
        'Managed an annual marketing budget across digital and offline channels.'
      ]
    },
    {
      company: 'Serena Global Pvt Ltd',
      role: 'Team Leader, Sales',
      location: 'Gurgaon, NCR',
      startDate: 'Oct 2017',
      endDate: 'Jun 2021',
      bullets: [
        'Consistently exceeded quarterly sales targets by an average of 15%.',
        'Mentored a team of 6 associates, improving retention and performance.'
      ]
    }
  ],
  education: [
    {
      school: 'Symbiosis Institute of Management Studies',
      degree: 'Masters',
      field: 'Business Administration',
      location: 'Pune, Maharashtra',
      endDate: '2010'
    },
    {
      school: 'Osmania University',
      degree: 'Bachelor of Technology',
      field: 'Computer Science',
      location: 'Hyderabad, Telangana',
      endDate: '2008'
    }
  ],
  skills: ['Brand Strategy', 'Digital Marketing', 'Team Leadership', 'CRM Tools', 'Data Analysis'],
  languages: [
    { name: 'English', level: 'Fluent' },
    { name: 'Hindi', level: 'Native' }
  ],
  projects: [],
  certifications: [{ name: 'Six Sigma Green Belt', issuer: 'ASQ', date: '2019' }],
  sectionOrder: ['summary', 'experience', 'education', 'skills', 'certifications', 'languages']
};
