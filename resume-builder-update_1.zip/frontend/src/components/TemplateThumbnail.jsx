import { useEffect, useMemo, useRef, useState } from 'react';
import { renderResumeHTML } from '../../../shared/resumeHtmlRenderer.js';
import { SAMPLE_RESUME } from '../sampleResume.js';

const PAGE_WIDTH = 794; // matches the A4-at-96dpi width baked into resumeHtmlRenderer.js
const PAGE_HEIGHT = 1123;

// Renders a real, scaled-down preview of a template — using the exact same
// HTML the live editor and the downloaded PDF use — cropped to show just the
// top of the page. This is what makes the template gallery show actual
// resume layouts instead of flat color blocks.
export default function TemplateThumbnail({ template, className = '' }) {
  const containerRef = useRef(null);
  const [scale, setScale] = useState(0.3);
  const html = useMemo(() => renderResumeHTML(SAMPLE_RESUME, template), [template]);

  useEffect(() => {
    function updateScale() {
      if (containerRef.current) {
        setScale(containerRef.current.offsetWidth / PAGE_WIDTH);
      }
    }
    updateScale();
    window.addEventListener('resize', updateScale);
    return () => window.removeEventListener('resize', updateScale);
  }, []);

  return (
    <div ref={containerRef} className={`relative overflow-hidden bg-white ${className}`}>
      <iframe
        title={`${template.name} preview`}
        srcDoc={html}
        tabIndex={-1}
        style={{
          width: PAGE_WIDTH,
          height: PAGE_HEIGHT,
          border: 'none',
          transform: `scale(${scale})`,
          transformOrigin: 'top left',
          pointerEvents: 'none'
        }}
      />
    </div>
  );
}
