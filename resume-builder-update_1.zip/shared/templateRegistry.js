// Central registry of every resume template offered to users.
//
// Design approach: rather than hand-building 20 completely bespoke React
// components (a maintenance nightmare), each template is a combination of
// one of 7 structural LAYOUT ENGINES (implemented once each, in
// resumeHtmlRenderer.js) plus a THEME (accent color, font pairing, density).
// This is how most production resume builders actually work, and it means
// adding template #21 is a ~10-line config addition, not a new component.
//
// This file is framework-agnostic (no React, no Node built-ins) so it can be
// imported by both the backend (for PDF rendering with Puppeteer) and the
// frontend (for the live preview), guaranteeing the preview always matches
// the exported PDF exactly (WYSIWYG).

export const LAYOUTS = {
  SINGLE_COLUMN: 'single-column',
  SIDEBAR_LEFT: 'sidebar-left',
  SIDEBAR_RIGHT: 'sidebar-right',
  TWO_COLUMN_BODY: 'two-column-body',
  TIMELINE: 'timeline',
  COMPACT_MINIMAL: 'compact-minimal',
  CREATIVE_HEADER: 'creative-header'
};

export const GOOGLE_FONTS = {
  inter: 'Inter:wght@400;500;600;700',
  poppins: 'Poppins:wght@400;500;600;700',
  lora: 'Lora:wght@400;500;600;700',
  merriweather: 'Merriweather:wght@400;700',
  playfair: 'Playfair+Display:wght@400;600;700',
  nunito: 'Nunito+Sans:wght@400;600;700',
  cormorant: 'Cormorant+Garamond:wght@400;600;700',
  jetbrains: 'JetBrains+Mono:wght@400;500;700',
  sourceSans: 'Source+Sans+3:wght@400;600;700'
};

const FONT_STACKS = {
  inter: "'Inter', system-ui, sans-serif",
  poppins: "'Poppins', system-ui, sans-serif",
  lora: "'Lora', Georgia, serif",
  merriweather: "'Merriweather', Georgia, serif",
  playfair: "'Playfair Display', Georgia, serif",
  nunito: "'Nunito Sans', system-ui, sans-serif",
  cormorant: "'Cormorant Garamond', Georgia, serif",
  jetbrains: "'JetBrains Mono', 'Courier New', monospace",
  sourceSans: "'Source Sans 3', system-ui, sans-serif",
  georgia: "Georgia, 'Times New Roman', serif"
};

export function fontStack(key) {
  return FONT_STACKS[key] || FONT_STACKS.inter;
}

// Human-friendly labels for every font key, for font pickers in the editor.
export const FONT_OPTIONS = [
  { key: 'inter', label: 'Inter' },
  { key: 'poppins', label: 'Poppins' },
  { key: 'lora', label: 'Lora' },
  { key: 'merriweather', label: 'Merriweather' },
  { key: 'playfair', label: 'Playfair Display' },
  { key: 'nunito', label: 'Nunito Sans' },
  { key: 'cormorant', label: 'Cormorant Garamond' },
  { key: 'jetbrains', label: 'JetBrains Mono' },
  { key: 'sourceSans', label: 'Source Sans 3' },
  { key: 'georgia', label: 'Georgia (system font)' }
];

// The section keys a resume can be split into, in the order they're offered
// for reordering in the editor. Kept here (rather than only inline in the
// renderer) so the frontend can build "reorder sections" and "per-section
// font" controls without duplicating this list.
export const SECTION_KEYS = ['summary', 'experience', 'education', 'skills', 'projects', 'certifications', 'languages'];

export const SECTION_LABELS = {
  summary: 'Summary',
  experience: 'Experience',
  education: 'Education',
  skills: 'Skills',
  projects: 'Projects',
  certifications: 'Certifications',
  languages: 'Languages'
};

// id must be unique and stable — it is stored on every Resume document.
export const TEMPLATES = [
  { id: 'classic-01', name: 'Classic Navy', category: 'Classic', layout: LAYOUTS.SINGLE_COLUMN, defaultAccentColor: '#1e3a8a', headingFont: 'merriweather', bodyFont: 'inter', density: 'comfortable', atsFriendly: true, description: 'A timeless single-column layout with a navy accent. Safe, professional, ATS-friendly.' },
  { id: 'classic-02', name: 'Classic Charcoal', category: 'Classic', layout: LAYOUTS.SINGLE_COLUMN, defaultAccentColor: '#111827', headingFont: 'lora', bodyFont: 'inter', density: 'compact', atsFriendly: true, description: 'Tighter spacing variant of our classic layout for longer career histories.' },
  { id: 'executive-01', name: 'Executive Maroon', category: 'Executive', layout: LAYOUTS.SINGLE_COLUMN, defaultAccentColor: '#7c2d12', headingFont: 'playfair', bodyFont: 'sourceSans', density: 'comfortable', atsFriendly: true, description: 'A refined layout with serif headings suited for senior and leadership roles.' },
  { id: 'elegant-01', name: 'Elegant Gold', category: 'Elegant', layout: LAYOUTS.SINGLE_COLUMN, defaultAccentColor: '#b45309', headingFont: 'cormorant', bodyFont: 'nunito', density: 'comfortable', atsFriendly: true, description: 'Soft serif headings with a warm gold accent for a polished, elegant feel.' },
  { id: 'academic-01', name: 'Academic Black', category: 'Academic', layout: LAYOUTS.SINGLE_COLUMN, defaultAccentColor: '#111827', headingFont: 'georgia', bodyFont: 'georgia', density: 'compact', atsFriendly: true, description: 'A formal, no-frills format suited to CVs, research and academic applications.' },

  { id: 'modern-sidebar-01', name: 'Modern Teal', category: 'Modern', layout: LAYOUTS.SIDEBAR_LEFT, defaultAccentColor: '#0d9488', headingFont: 'poppins', bodyFont: 'inter', density: 'comfortable', atsFriendly: false, description: 'A left sidebar for contact info and skills, teal accent, clean sans-serif type.' },
  { id: 'modern-sidebar-02', name: 'Modern Purple', category: 'Modern', layout: LAYOUTS.SIDEBAR_LEFT, defaultAccentColor: '#7c3aed', headingFont: 'poppins', bodyFont: 'inter', density: 'comfortable', atsFriendly: false, description: 'Same modern sidebar structure with a bold purple identity.' },
  { id: 'elegant-02', name: 'Rose Gold Sidebar', category: 'Elegant', layout: LAYOUTS.SIDEBAR_LEFT, defaultAccentColor: '#be123c', headingFont: 'playfair', bodyFont: 'nunito', density: 'comfortable', atsFriendly: false, description: 'An elegant serif sidebar layout with a rose-gold accent.' },
  { id: 'tech-sidebar-01', name: 'Tech Dark Sidebar', category: 'Tech', layout: LAYOUTS.SIDEBAR_LEFT, defaultAccentColor: '#22c55e', headingFont: 'jetbrains', bodyFont: 'inter', density: 'compact', atsFriendly: false, description: 'A dark sidebar with monospace headings for engineering and technical roles.', sidebarDark: true },

  { id: 'tech-01', name: 'Tech Slate', category: 'Tech', layout: LAYOUTS.SIDEBAR_RIGHT, defaultAccentColor: '#0ea5e9', headingFont: 'jetbrains', bodyFont: 'inter', density: 'compact', atsFriendly: false, description: 'Main content on the left, contact/skills sidebar on the right; monospace accents.' },
  { id: 'corporate-02', name: 'Corporate Charcoal', category: 'Corporate', layout: LAYOUTS.SIDEBAR_RIGHT, defaultAccentColor: '#1f2937', headingFont: 'inter', bodyFont: 'inter', density: 'comfortable', atsFriendly: false, description: 'A sober, corporate right-sidebar layout for finance, consulting and law.' },

  { id: 'executive-02', name: 'Executive Split', category: 'Executive', layout: LAYOUTS.TWO_COLUMN_BODY, defaultAccentColor: '#1e40af', headingFont: 'playfair', bodyFont: 'sourceSans', density: 'comfortable', atsFriendly: false, description: 'Full-width header, then a two-column body balancing experience and credentials.' },
  { id: 'corporate-01', name: 'Corporate Steel', category: 'Corporate', layout: LAYOUTS.TWO_COLUMN_BODY, defaultAccentColor: '#334155', headingFont: 'inter', bodyFont: 'inter', density: 'comfortable', atsFriendly: false, description: 'Balanced two-column body in a steel-blue palette.' },
  { id: 'tech-02', name: 'Tech Split Indigo', category: 'Tech', layout: LAYOUTS.TWO_COLUMN_BODY, defaultAccentColor: '#4f46e5', headingFont: 'poppins', bodyFont: 'inter', density: 'compact', atsFriendly: false, description: 'Two-column body with indigo accents and monospace skill tags.' },

  { id: 'timeline-01', name: 'Career Timeline Teal', category: 'Timeline', layout: LAYOUTS.TIMELINE, defaultAccentColor: '#0f766e', headingFont: 'poppins', bodyFont: 'inter', density: 'comfortable', atsFriendly: false, description: 'Experience presented as a vertical timeline with connected milestones.' },
  { id: 'timeline-02', name: 'Career Timeline Indigo', category: 'Timeline', layout: LAYOUTS.TIMELINE, defaultAccentColor: '#4338ca', headingFont: 'poppins', bodyFont: 'inter', density: 'comfortable', atsFriendly: false, description: 'The timeline layout in a deep indigo palette.' },

  { id: 'minimalist-01', name: 'Minimalist Gray', category: 'Minimalist', layout: LAYOUTS.COMPACT_MINIMAL, defaultAccentColor: '#4b5563', headingFont: 'inter', bodyFont: 'inter', density: 'compact', atsFriendly: true, description: 'The most stripped-down, ATS-safe layout: dense, plain, no decoration.' },
  { id: 'fresh-grad-01', name: 'Fresh Graduate Green', category: 'Minimalist', layout: LAYOUTS.COMPACT_MINIMAL, defaultAccentColor: '#16a34a', headingFont: 'nunito', bodyFont: 'nunito', density: 'comfortable', atsFriendly: true, description: 'A friendly, approachable minimal layout suited to early-career resumes.' },

  { id: 'creative-01', name: 'Creative Orange Header', category: 'Creative', layout: LAYOUTS.CREATIVE_HEADER, defaultAccentColor: '#ea580c', headingFont: 'poppins', bodyFont: 'inter', density: 'comfortable', atsFriendly: false, description: 'A bold color-block header with photo support for design and creative roles.', supportsPhoto: true },
  { id: 'creative-02', name: 'Creative Pink Header', category: 'Creative', layout: LAYOUTS.CREATIVE_HEADER, defaultAccentColor: '#db2777', headingFont: 'poppins', bodyFont: 'inter', density: 'comfortable', atsFriendly: false, description: 'The bold header layout in a vivid pink palette.', supportsPhoto: true }
];

export function getTemplateById(id) {
  return TEMPLATES.find((t) => t.id === id);
}

export function listTemplateSummaries() {
  return TEMPLATES.map(({ id, name, category, layout, defaultAccentColor, atsFriendly, description, supportsPhoto }) => ({
    id,
    name,
    category,
    layout,
    defaultAccentColor,
    atsFriendly,
    description,
    supportsPhoto: !!supportsPhoto
  }));
}
